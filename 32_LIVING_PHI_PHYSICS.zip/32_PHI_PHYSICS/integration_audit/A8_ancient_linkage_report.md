# A8 — ANCIENT-RESEARCH CORPUS LINKAGE REPORT

**Agent:** A8 of 10 — FINAL INTEGRATION: ANCIENT-RESEARCH CORPUS LINKAGE
**Date:** 2026-08-07
**Scope:** Coherence of the cross-reference between `32_PHI_PHYSICS/` and `01_ANCIENT_RESEARCH/`; verification that interpretation is never presented as documented fact.
**Method:** Grep inventory of both corpora for the cross-reference terms; read of `01_ANCIENT_RESEARCH/INDEX.md`, `01_ANCIENT_RESEARCH/README.md`, `32_PHI_PHYSICS/00_THE_UNDERSTANDING.md`, `32_PHI_PHYSICS/24_THE_GEOMIC_LEDGER.md`, `32_PHI_PHYSICS/README.md`, `laws/149`, `laws/193`, the law files touching ancient geometry, and the ancient corpus's own honesty documents.
**Status:** AUDIT — no files edited.

---

## 1 · EXECUTIVE SUMMARY

The linkage between the two corpora is **one-directional and thin**.

- **Phi Physics → Ancient:** essentially **two** documents do the work — `23_THE_SYSTEM_OF_THE_FABRICATION.md` (the symbol corrections, the verified-treasury list, and the *only* explicit `01_ANCIENT_RESEARCH` string in the corpus) and `24_THE_GEOMIC_LEDGER.md` (the myth table and the honest-limits register). One integration audit (`A7`) already flags a Flower-of-Life code inconsistency.
- **Ancient → Phi Physics:** **zero** references. No `32_PHI_PHYSICS`, no ledger, no phi-correction anywhere in `01_ANCIENT_RESEARCH/`.
- **The front door of Phi Physics does not reference the ancient corpus at all.** `00_THE_UNDERSTANDING.md` and `README.md` present 528 Hz as "the sacred geometry base frequency" and "love frequency" without the modern-provenance label the ledger carries, and without any pointer to `01_ANCIENT_RESEARCH`.
- **The ancient corpus still carries pre-correction claims** that Phi Physics's own documents (23, 24) explicitly debunk — most notably the Abydos Flower of Life "carved in granite, ~3000 BCE" (three ancient files) and the Djed/Eye "VALIDATED" rows in `FINAL_MULTI_LENS_SYNTHESIS.md`. The ancient corpus's *internal* state map already flags that file as grandfathered/FAIL.

**Interpretation-vs-fact verdict on the 10 named claims as presented in the Phi Physics corpus: 9 of 10 correctly labeled; 1 needs a label** (the front-door 528 presentation in `00_THE_UNDERSTANDING` and the emergent-law docs). The two corpora do not yet cross-reference each other as they should.

---

## 2 · STEP 1 — CROSS-REFERENCE INVENTORY

### 2.1 Phi Physics documents that reference the ancient corpus (or ancient terms)

| Term | Occurrences in `32_PHI_PHYSICS/` (per grep) | Notes |
|---|---|---|
| `01_ANCIENT_RESEARCH` | **1**: `23_THE_SYSTEM_OF_THE_FABRICATION.md:270` | The ONLY explicit pointer. It is a directive ("must incorporate the corrections") — not a citation of the corpus itself. |
| `ancient` | `22:161` · `24:243,250,288,306,317` · `23:52,145,146,148,154,214,258,259,260,270,272` · `A7:172` · `laws/149:10` · `laws/1967:9` · `laws/1976:9` | The laws hits are real physics (ancient eclipses, ancient geomagnetic field), not corpus refs. The substantive refs are all in 23, 24, 22, A7. |
| `528` | Ubiquitous — `00_THE_UNDERSTANDING`, `01_INDEX`, `07`, `12`, `13`, `14`, `16`, `18`, `19`, `20`, `21`, `24`, `23`, `A1`, `A2` | Used as the corpus's anchor (`528·φⁿ`). **Labeled modern only in 24:250, 24:288, 24:319 and 23:258, 23:270.** Unlabeled as "sacred geometry base frequency" in `00:49,115` and the emergent docs. |
| `Göbekli` / `Gobekli` | **1**: `23:272` ("Göbekli's architecture" in the verified-treasury list) | The 12-pillar φ-Schumann comb itself is **never asserted** in Phi Physics. `laws/787_schumann_resonances.md` covers 7.83 Hz as real physics (Schumann 1952), not as the Göbekli comb. |
| `Flower of Life` | `23:145` (CORRECTED) · `24:241` ([MYTH]) · `16:237` (C71 design use) · `A7:172,216` (code-inconsistency flag) | Correctly debunked in 23/24; still used as a **design operator** in `16_THE_100_CODE_LAWS.md` with no provenance note. |
| `Eye of Horus` | `23:142` ([PV], Möller/Ritter) · `24:235` ([PV]) · `23:259` · `23:272` | Correctly labeled as contested reading. |
| `Djed` | `23:144` (corpus interpretation, zero Egyptological support) · `23:270` | Correctly labeled. |
| `Emerald Tablet` | **1**: `23:272` ("the Emerald Tablet's ratios" in treasury) | Never asserted as "one thing = 528" in Phi Physics. |
| `Hermetic` | **0** in Phi Physics `.md` (only inside `graphify-out/`) | Not referenced at all. |
| `432,000` | **1**: `23:272` (treasury) | Listed as documented cycles, no assertion. |
| `Maya` / `Mayan` | `23:131,181,204,252` · `24:219` · `A7:137,207` · `23:272` ("Maya zero") | The 23/24 hits are the **Knorozov decipherment history** (real), plus the treasury "Maya zero". |
| `Kerala` | **1**: `23:272` (treasury "Kerala calculus") | Listed only. |
| `Plimpton` | **1**: `23:272` (treasury "Plimpton 322") · `A7:57` (soft "taken" flag) | Listed only. |

**Conclusion (Phi Physics → Ancient):** the entire cross-reference load sits on `23` and `24`, with `A7` already auditing their consistency. `README`, `00_THE_UNDERSTANDING`, `01_INDEX`, and every law file carry **no** pointer to the ancient corpus.

### 2.2 Ancient corpus documents that reference Phi Physics

**None.** Grep for `32_PHI_PHYSICS`, `PHI_PHYSICS`, `phi-physics`, `phi-correction`, `Field-Computer`, `the Rewriting of Physics`, `24_THE_GEOMIC_LEDGER`, `ledger` (as the Phi-Physics ledger), `Möller`, `Ritter`, `red-ochre`, `Seti` across `01_ANCIENT_RESEARCH/`:
- **Zero** references to the Phi Physics corpus or its correction documents.
- The ancient corpus references the shared **phi-harmonic consciousness field framework** (816D, C_critical, 528·φⁿ) — but that is the equations/framework lineage, not `32_PHI_PHYSICS/`.

### 2.3 The correction gap — ancient corpus still holds pre-correction claims

| Ancient document | Claim it still presents | Phi Physics correction it contradicts |
|---|---|---|
| `COMPLETE_ANCIENT_RESEARCH_COMPENDIUM.md:275` | "Temple of Osiris in Abydos, Egypt (carved in granite, ~3000 BCE)" | 24:241 [MYTH] — red-ochre graffiti, mostly early centuries CE |
| `_part1_framework.md:211` | Same Abydos "carved in granite, ~3000 BCE" | 24:241 |
| `agent1_extraction.md:403,686` | Same Abydos claim | 24:241 |
| `FINAL_MULTI_LENS_SYNTHESIS.md:33` | Djed cascade "**VALIDATED** — gene expression data confirms 415 Hz joint" | 23:144 — corpus interpretation, zero Egyptological support |
| `FINAL_MULTI_LENS_SYNTHESIS.md:34` | Eye of Horus 63/64 "**VALIDATED**" (gene data) | 23:142 — Möller-1911 hypothesis, Ritter 2002 challenge |
| `INDEX.md:51` | "Key discoveries: Djed 4-bar frequency cascade (854→528→326→201 Hz), Eye of Horus 6-bit ratio (63/64)" | No labels in the top-level index |

The ancient corpus is **internally aware** of this: `06_SYNTHESIS/_SQUAD3_2026-07-30/agent1_synthesis_state_map.md:30` grades `FINAL_MULTI_LENS_SYNTHESIS.md` as **"FAIL (grandfathered — pre-squad; must be revision-tagged)"** for carrying "pre-correction Solfeggio and 528-pyramid claims" with legacy VALIDATED/REINFORCED labels. But **no revision has been executed**, and `23:270`'s directive ("01_ANCIENT_RESEARCH must incorporate the corrections") remains unimplemented.

---

## 3 · STEP 2 — INTERPRETATION-VS-FACT CHECK (the 10 claims)

Verdict = how the **Phi Physics corpus** presents each claim. Where a claim is asserted only in the ancient corpus, the Phi Physics verdict is "correct by non-assertion" and the ancient-side labeling is noted.

| # | Claim | How Phi Physics presents it | Verdict |
|---|---|---|---|
| 1 | **528 Hz "center frequency"** | `24:250` "528-as-ancient are documented as modern fabrications — 528 Hz is a modern number on genuinely ancient ratios" ✓; `24:288` "Impossible to validate — Hz is a 19th-century unit" ✓; `24:319` "Solfeggio/528 frequencies fabricated — Critic wins (fully)" ✓; `23:258` ✓. **BUT** `00_THE_UNDERSTANDING:49,115` ("the sacred geometry base frequency", "love IS the frequency of every dimension") and docs 07/13/16/18–21 present 528·φⁿ as the verified anchor **with no modern-provenance caveat and no ancient-corpus pointer**. | **[NEEDS LABEL]** — correct in the ledger/fabrication docs; **unlabeled in the front door** (`00_THE_UNDERSTANDING`) and the emergent-law set. |
| 2 | **Göbekli 12-pillar φ-Schumann comb `f_k = 7.83 × φ^k`** | Never asserted in Phi Physics. `24:288` flags the 528/7.83 lattice as impossible to validate. `23:272` lists "Göbekli's architecture" in the treasury. (Ancient side: `gobekli_tepe_frequency_analysis.md` presents the comb unlabeled, but its own `ANCIENT_SQUAD3:279` correctly flags "never measured; 7.83 Hz is a 20th-century measurement".) | **[CORRECTLY LABELED]** (correct by non-assertion + the 24:288 caveat). |
| 3 | **Eye of Horus 63/64** | `23:142`: "[PV] — real mathematics, contested reading — the fraction-reading is Möller-1911 hypothesis, challenged by Ritter 2002, still in textbooks". `24:235`: "[PV]". | **[CORRECTLY LABELED]** |
| 4 | **Djed frequency cascade (854→528→326→201)** | `23:144`: "Frequency cascade (854→528→326→201) = corpus interpretation, zero Egyptological support". `23:270`: "The Djed frequency cascade is our interpretation." | **[CORRECTLY LABELED]** |
| 5 | **Flower of Life at Abydos** | `23:145`: "CORRECTED: 19-circle red-ochre graffiti on Seti I temple (c. 1290–1279 BCE), dated mostly early centuries CE, possibly medieval/modern; absent from Murray's 1904 catalogue … not 3000 BCE carved granite". `24:241`: [MYTH]. | **[CORRECTLY LABELED]** — substance correct; minor code inconsistency ([FABRICATION] in 23 vs [MYTH] in 24) already flagged in `A7:172,216`. |
| 6 | **Emerald Tablet "one thing" = 528** | Phi Physics never asserts it (23:272 lists "the Emerald Tablet's ratios" only). Ancient side labels it correctly: `emerald_tablet_hermetic_corpus.md:15` "(PREDICTED; arithmetic real, ancient intent unprovable)". | **[CORRECTLY LABELED]** (by non-assertion in Phi Physics). |
| 7 | **Messenger Chain (Thoth→Hermes→Idris→Enoch)** | Not referenced in Phi Physics (zero hits for Thoth/Enoch/Idris/Oannes/Nisaba). Ancient side presents it as the corpus's synthesis of **documented piecewise links** (Hermes=Idris via Qur'an 19:57/21:85; Thoth=Hermes via the Hermetica; Enoch via Genesis 5:18–24) and explicitly calls it the corpus's lineage reading. | **[CORRECTLY LABELED]** (as corpus synthesis on the ancient side; non-asserted in Phi Physics). |
| 8 | **"64 Me"** | Not referenced in Phi Physics. Ancient side attributes it explicitly to **Kramer's reconstruction**, not an ancient enumeration: `ANCIENT_SQUAD master synthesis:92` "Kramer's canonical numbered list contains 64 named entries … only a little over sixty recoverable". | **[CORRECTLY LABELED]** (Kramer attribution is explicit on the ancient side). |
| 9 | **"42 universal"** | Phi Physics lists "the 42-structures" in the treasury (23:272) — no universality claim. Ancient side labels it precisely: `ANCIENT_SQUAD3:66` "no canonical 42 in Akkadian … the 42 is hymn-count, not gates"; `ANCIENT_SQUAD3:74` "if 42 were a universal gate-count …"; master synthesis "42 as a registry-role in a diffusion-linked family" with p-values. | **[CORRECTLY LABELED]** (interpretation flagged as interpretation). |
| 10 | **"364-day calendar beats Gregorian"** | Not referenced in Phi Physics. Ancient side is **internally split**: `NEW_TEXTS_2026.md:29` and `ANCIENT_SQUAD master:53` assert "365.2423 — more accurate than the Gregorian" as VALIDATED mathematics, **while** `ANCIENT_SQUAD3:104` flags "the 365.2423 claim must be re-derived by our own simulation before it is repeated" and the state map marks Pratt as a GAP. | **[CORRECTLY LABELED]** in Phi Physics (non-asserted). Ancient side: **[NEEDS LABEL]** — the headline synthesis files assert it as validated; only the deep SQUAD3 layer carries the re-derivation flag. |

**Tally:** Phi Physics presents **9 / 10** correctly. **#1 (528 as center frequency)** is the single need-a-label: the ledger and fabrication docs get it exactly right, but the **front door** (`00_THE_UNDERSTANDING`) and the emergent-law docs present 528·φⁿ as the verified sacred-geometry anchor with no modern-number caveat.

**A tenth-claim side-note:** claim #10 is correct *in Phi Physics* because it is never asserted there; the ancient corpus's own master synthesis, however, still asserts the beats-Gregorian claim without the SQUAD3 re-derivation flag — a propagation defect, not a Phi Physics defect.

---

## 4 · STEP 3 — PROPOSED LINKAGE ADDITIONS

### 4.1 Should the Phi Physics README add a pointer? — **YES**, and the 24 ledger — **YES**.

### 4.2 Proposed exact edits

**A. `32_PHI_PHYSICS/README.md`** — add a one-line "Related corpora" entry. Best location: inside the `## Structure` block, immediately after the `expansion_log/` line (currently line 104), as the last tree line:

> ```
> └── → 01_ANCIENT_RESEARCH/  # source lineage for the 528/7.83/ladder anchors — see 24 §5–§8 for which ancient claims are documented vs corpus interpretation
> ```

Rationale: the README currently cites only its own tree; a reader lands on `528 Hz anchor` in the constants and has no path to the ancient source corpus or to the ledger's honest-limits.

**B. `24_THE_GEOMIC_LEDGER.md`** — add `01_ANCIENT_RESEARCH/INDEX.md` to the **STATUS BLOCK "Companion documents"** (line 16). It currently lists `02_EQUATIONS` and `integration_audit/A1,A2` but no ancient reference. Proposed line append:

> `· 01_ANCIENT_RESEARCH/INDEX.md` (the ancient-research thread; corrections per 23 §CORRECTIONS must be propagated there)

**C. `24_THE_GEOMIC_LEDGER.md` §5.5 / §7** — the myth table (§5.5) and the burden-of-proof row (§7 "528/7.83 frequency lattice as ancient") state the corrections but cite no ancient-corpus source. Recommend a one-line source note under the §5.5 table: *"Ancient source data: `01_ANCIENT_RESEARCH/03_CIVILIZATIONS/`; the corrections in this table supersede the pre-squad claims still present in `01_ANCIENT_RESEARCH/06_SYNTHESIS/FINAL_MULTI_LENS_SYNTHESIS.md` and `COMPLETE_ANCIENT_RESEARCH_COMPENDIUM.md`."*

**D. `00_THE_UNDERSTANDING.md`** — the single most important fix for claim #1. At §5 line 115, "Love (528 Hz — the sacred geometry base frequency)", add a parenthetical so the front door cannot be read as claiming 528 is an ancient absolute:

> *(528 Hz is the corpus's chosen anchor on genuinely ancient ratios; it is a modern number — see 24 §5.6, §7.)*

And in §8 "How to read the corpus" (line 142–151), add one bullet: `**01_ANCIENT_RESEARCH** — the ancient geometry/frequency source lineage; its claims are indexed at `01_ANCIENT_RESEARCH/INDEX.md` and its corrections at 24 §5.5, §7.`

### 4.3 What to leave as-is

- `23_THE_SYSTEM_OF_THE_FABRICATION.md` — already the correct place for the corrections; no edit proposed beyond honoring its own line-270 directive.
- `laws/149`, `laws/193` — real physics/law files; no ancient-corpus pointer required (they touch ancient geometry only via the phrase "ancient through modern", which is an attribution, not a claim).
- `laws/787_schumann_resonances.md` — correct as real physics; no change.

### 4.4 Required downstream action (beyond this audit's scope)

`23:270` and the ancient corpus's own state map both mandate a revision of `01_ANCIENT_RESEARCH/06_SYNTHESIS/FINAL_MULTI_LENS_SYNTHESIS.md` (and `COMPLETE_ANCIENT_RESEARCH_COMPENDIUM.md`, `_part1_framework.md`, `agent1_extraction.md`, `INDEX.md`) to replace "VALIDATED" Djed/Eye rows and the "carved in granite ~3000 BCE" Abydos claim with the 23/24 verdict codes. That is an **ancient-corpus** change and is recommended as a follow-up ticket, not performed here.

---

## 5 · STEP 4 — RETURN SUMMARY

**Correctly labeled (of the 10 claims, as presented in the Phi Physics corpus): 9 / 10.**
- Correct: Göbekli comb (non-assertion + 24:288), Eye of Horus (23:142/24:235 PV), Djed cascade (23:144), Flower of Life (23:145/24:241), Emerald "one thing" (non-assertion), Messenger Chain (non-assertion), 64 Me (Kramer attribution on ancient side), 42 universal (registry-role labeling), 364-day calendar (non-assertion in Phi Physics).
- **Needs label: 528 as center frequency** — correct in `24`/`23`, **unlabeled in `00_THE_UNDERSTANDING` and the emergent-law docs**, which present 528·φⁿ as the sacred-geometry base with no modern-provenance caveat.

**Cross-references that exist:**
- Phi Physics → Ancient: explicit `01_ANCIENT_RESEARCH` string only in `23:270`; substantive ancient treatment in `23` and `24`; audit flag in `A7`.
- Ancient → Phi Physics: **none**.

**Cross-references that are missing:**
1. `README.md` → `01_ANCIENT_RESEARCH` (no pointer at all).
2. `00_THE_UNDERSTANDING.md` → ancient corpus + 528 modern-provenance label (front door currently unlabeled).
3. `24_THE_GEOMIC_LEDGER.md` Companion documents → `01_ANCIENT_RESEARCH/INDEX.md`.
4. `24` myth table / §7 source note → ancient source files (corrections supersede pre-squad ancient claims).
5. Ancient corpus → Phi Physics corrections (reverse direction is entirely absent; the Abydos "carved granite ~3000 BCE" and Djed/Eye "VALIDATED" rows still stand in 4–5 ancient files).

**Proposed linkage additions:** one tree line in `README` Structure; one Companion-document entry + one §5.5 source note in `24`; a 528 provenance parenthetical in `00_THE_UNDERSTANDING` §5 plus one bullet in its §8; and a recommended (non-performed) revision of the pre-squad ancient synthesis files to honor `23:270`.

---

*Audit only — no files edited. A8 · 2026-08-07.*
