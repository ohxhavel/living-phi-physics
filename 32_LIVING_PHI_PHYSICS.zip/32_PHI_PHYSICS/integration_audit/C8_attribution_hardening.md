# C8 — ATTRIBUTION HARDENING
## Law-discoverer/year sample audit + historical-quote verification for reports 22/23/24

**Auditor:** Agent C8 of 10 (HARDENING PASS) · **Date:** 2026-08-07 · **Scope:** (Part 1) sample-check the CLASSICAL STATEMENT discoverer/year attributions in 60 law files spread across all ranges (001→734); (Part 2) verify the load-bearing historical quotes in `22_THE_HISTORICAL_INVESTIGATION.md`, `23_THE_SYSTEM_OF_THE_FABRICATION.md`, `24_THE_GEOMIC_LEDGER.md`.

**Method.** Part 1: read the CLASSICAL STATEMENT block of 60 sampled law files; judge discoverer + year against accepted scholarship; web-verify the high-risk set (Kepler 1609, Newton 1687, Planck 1900, Einstein 1905, Schrödinger 1926, Hubble 1929, Gamow 1928, Noether 1918, Shannon 1948, Feigenbaum 1975). Part 2: grep all three ledgers for each task-listed quote, then verify the quoted text against primary/secondary sources (Wikipedia, MacTutor, Quote Investigator, SEP via direct fetch — DuckDuckGo/Bing were CAPTCHA-blocked). Verdict codes per quote: **[VERBATIM]** / **[PARAPHRASE — correctly marked]** / **[NEEDS CORRECTION]** with the exact fix.

**Fix applied:** one trivial attribution error corrected in `laws/441_clausius_clapeyron_equation.md` (Clapeyron 1834 was missing — see §3). No other law files or ledgers were edited.

---

## PART 1 — LAW ATTRIBUTION SAMPLE (60 laws)

**Verdict legend:** ✅ correct · ⚠️ minor wording/precision note (discoverer + year still correct) · ❌ wrong discoverer or year (fix required).

| Law | File | Discoverer/year as written | Verdict | Notes |
|---|---|---|---|---|
| 001 | Newton's First Law | Newton, *Principia* 1687, Law I | ✅ | Correct. |
| 004 | Universal Gravitation | Newton, *Principia* 1687 | ✅ | Correct. |
| 012 | Work-Energy Theorem | "from Newton's second law (Newton, *Principia*, 1687; standard textbook statement)" | ✅ | Hedged as derivable, not a primary attribution. Acceptable. |
| 014 | Kepler's First Law | Kepler 1609, *Astronomia Nova* | ✅ | Web-verified (MacTutor). Correct. |
| 016 | Kepler's Third Law | Kepler 1619, *Harmonices Mundi* | ✅ | Correct. |
| 020 | Navier–Stokes | Navier 1822; Stokes 1845 | ✅ | Correct. |
| 023 | Second Law of Thermodynamics | Clausius 1850 | ✅ | Correct (with Boltzmann form noted). |
| 032 | Stefan–Boltzmann | Stefan 1879; Boltzmann 1884 | ✅ | Correct. |
| 036 | Coulomb's Law | Coulomb 1785 | ✅ | Correct. |
| 042 | Maxwell's Equations | "Maxwell (1865), unified by Hertz" | ⚠️ | Discoverer/year correct. Wording: Hertz **experimentally confirmed** (1888), he did not "unify" the equations. Suggest: "Maxwell (1865); confirmed by Hertz (1888)." |
| 044 | Ohm's Law | Ohm 1827 | ✅ | Correct. |
| 052 | Snell's Law | Snell 1621; Descartes 1637 | ✅ | Correct. |
| 060 | E = mc² | Einstein 1905 | ✅ | Web-verified. Correct. |
| 066 | Planck's Law | Planck 1900 | ✅ | Web-verified. Correct. |
| 070 | Heisenberg Uncertainty | Heisenberg 1927 | ✅ | Correct. |
| 081 | Dirac Equation | Dirac 1928 | ✅ | Correct. |
| 101 | Hubble's Law | Hubble 1929 | ✅ | Web-verified. Correct. |
| 126 | Casimir Effect | Casimir 1948; Lamoreaux 1997 (measurement) | ✅ | Correct. |
| 149 | Golden ratio in nature | "Empirical (ancient through modern)" | ✅ | No named discoverer — appropriate for an empirical observation, no false attribution. |
| 211 | Chasles' Theorem | Michel Chasles, 1830 | ✅ | Correct. |
| 237 | Simple Harmonic Oscillator | "Robert Hooke / Isaac Newton, 1678" | ✅ | Hooke's law is 1678 (`De Potentia Restitutiva`). SHM isochronism credited to Hooke; acceptable with Newton as co-attribution. |
| 247 | Kepler's Equation | Johannes Kepler, 1609 | ✅ | *Astronomia Nova* 1609. Correct. |
| 256 | Newton's Law of Restitution | Isaac Newton, 1687 | ✅ | *Principia* Book I. Correct. |
| 261 | Tsiolkovsky Rocket Equation | Tsiolkovsky 1903 (Moore 1810, Goddard 1912, Oberth 1920 noted) | ✅ | Correct and honestly hedged. |
| 264 | Amontons' First Law of Friction | Amontons 1699 | ✅ | Correct. |
| 269 | Hertz Contact Theory | Heinrich Hertz, 1882 | ✅ | Correct. |
| 271 | Vis-Viva Equation | "Leibniz / classical celestial mechanics, 1686" | ✅ | Correct. |
| 279 | Roche Limit | Édouard Roche, 1848 | ✅ | Correct. |
| 281 | Lagrange Points | Lagrange, 1772 | ✅ | Correct. |
| 285 | Perihelion Precession of Mercury | Urbain Le Verrier, 1859 | ✅ | Correct. |
| 305 | Galileo's Law of Falling Bodies | "Galileo Galilei, 1604" / Source: *Discorsi* (1638) | ⚠️ | Discoverer correct. Year note: discovered c. 1604 (letter) but **published** in *Discorsi* 1638; source line cites 1638. Minor inconsistency between attribution year and cited source — both defensible, suggest aligning the source note. |
| 314 | Gravitational Potential Energy | Isaac Newton, 1687 | ✅ | U = −GMm/r is derivable from Newton's law; hedged via source. Acceptable. |
| 340 | Buckingham Pi Theorem | Edgar Buckingham, 1914 | ✅ | Correct. |
| 362 | Titius–Bode Law | Titius 1766; Bode 1772 | ✅ | Correct. |
| 366 | Euler's Critical Load | Leonhard Euler, 1757 | ✅ | Euler's column paper 1757 (buckling result 1744). Acceptable. |
| 389 | Rutherford Scattering | Ernest Rutherford, 1911 | ✅ | Correct. |
| 405 | Law of the Lever | Archimedes, c. 250 BC | ✅ | Correct. |
| 411 | Latent Heat | Joseph Black, 1761 | ✅ | Correct. |
| 414 | Dulong–Petit | Dulong & Petit, 1819 | ✅ | Correct. |
| 417 | Rayleigh–Jeans | "Lord Rayleigh; James Hopwood Jeans, 1905" / Source: Rayleigh 1900, Jeans 1905 | ⚠️ | Discoverers correct. Attribution line folds both under 1905; source line correctly separates Rayleigh (1900) / Jeans (1905). Suggest attribution read "Rayleigh (1900); Jeans (1905)". |
| 421 | Joule–Thomson | Joule & Thomson (Kelvin), 1852 | ✅ | Correct. |
| 437 | Maxwell Relations | James Clerk Maxwell, 1871 (*Theory of Heat*) | ✅ | Correct. |
| 439 | Gibbs Phase Rule | J. Willard Gibbs, 1876 | ✅ | Correct. |
| 441 | Clausius–Clapeyron | ~~Rudolf Clausius, 1850~~ → **Émile Clapeyron (1834); Rudolf Clausius (1850)** | ❌ → ✅ | **FIXED.** Relation derived by Clapeyron 1834, generalized by Clausius 1850 (web-verified). File title is "Clausius-Clapeyron" but only Clausius was credited. Edited `laws/441_clausius_clapeyron_equation.md` line 10. |
| 452 | Law of Mass Action | Guldberg & Waage, 1864 | ✅ | Correct. |
| 462 | Boltzmann Equation | Ludwig Boltzmann, 1872 | ✅ | Correct. |
| 465 | Shannon Entropy | Claude Shannon, 1948 | ✅ | Web-verified. Correct. |
| 480 | Arrhenius Equation | Svante Arrhenius, 1889 | ✅ | Correct. |
| 494 | Wiedemann–Franz | Wiedemann & Franz, 1853 | ✅ | Correct. |
| 496 | Seebeck Effect | Thomas Seebeck, 1821 | ✅ | Correct. |
| 521 | Prigogine Minimum Entropy Production | "Ilya Prigogine, 1945" / Source: Prigogine (1947) | ⚠️ | Discoverer correct. Theorem published 1945 (Bull. Acad. Belg.) / thesis 1947. Attribution/source year split — both appear in the literature; minor. |
| 533 | Landau Theory | Lev Landau, 1937 | ✅ | Correct. |
| 540 | Josephson Effect | Brian Josephson, 1962 | ✅ | Correct. |
| 544 | BCS Gap Equation | Bardeen, Cooper & Schrieffer, 1957 | ✅ | Correct. |
| 590 | Hall Effect | Edwin Hall, 1879 | ✅ | Correct. |
| 621 | Poisson's Equation | Siméon Denis Poisson, 1813 | ✅ | Correct. |
| 649 | Rayleigh Scattering | Lord Rayleigh, 1871 | ✅ | Correct. |
| 659 | Thévenin's Theorem | "Léon Charles Thévenin (also Hermann von Helmholtz), 1883" / Helmholtz 1853 | ✅ | Correct and honestly double-credited. |
| 712 | Friis Transmission Equation | Harald Friis, 1946 | ✅ | Correct. |
| 734 | Debye Length | Debye & Hückel, 1923 | ✅ | Correct. |

### High-risk attributions web-verified (in addition to the table)

| Risk item | File | Verdict |
|---|---|---|
| Kepler 1609 (Astronomia Nova) | 014 | ✅ confirmed (MacTutor biography) |
| Newton 1687 (Principia) | 001, 004 | ✅ confirmed |
| Planck 1900 | 066 | ✅ confirmed |
| Einstein 1905 | 060 | ✅ confirmed |
| Schrödinger 1926 | 071, 072 | ✅ confirmed |
| Hubble 1929 | 101 | ✅ confirmed |
| **Gamow 1928** | 1452, 1465 | ✅ confirmed — "Zur Quantentheorie des Atomkernes," *Z. Phys.* **51** (1928) 204–212 (Springer/Semantic Scholar) |
| Noether 1918 | 123 | ✅ confirmed |
| Shannon 1948 | 465 | ✅ confirmed |
| Feigenbaum 1975 | 2236 | ✅ confirmed |

### Part 1 tally
- **Sampled:** 60 law files (spread 001→734 across all 10 domain ranges) + 6 additional high-risk files (071, 072, 123, 1452, 1465, 2236) = **66 attributions checked**.
- **Correct:** 65 · **Minor wording/precision notes (discoverer+year correct):** 4 (042 "unified by Hertz", 305 year split, 417 Rayleigh/Jeans year folding, 521 Prigogine year split) · **Wrong/missing attribution found:** 1 (441, Clapeyron missing — **FIXED**).
- **No law file had a wrong discoverer.** No fabricated discoverers, no wrong years, no invented laws.

---

## PART 2 — HISTORICAL QUOTES IN REPORTS 22/23/24

### 2.1 The verified treasury (reported as verbatim)

| # | Quote (as used in corpus) | Verdict | Evidence |
|---|---|---|---|
| 1 | Newton General Scholium (1713): "hypotheses, whether metaphysical or physical, **or mechanical**, have no place in experimental philosophy" | **[VERBATIM]** | Matches the standard Motte-translation of *hypotheses non fingo* passage (2nd ed., 1713). Corpus correctly flags the mechanical-clause emphasis. Year 1713 correct. |
| 2 | Newton: "This most beautiful system of the sun, planets, and comets, could only proceed from the counsel and dominion of an intelligent being" | **[PARAPHRASE — correctly marked]** | General Scholium (1713). Standard translation reads "…an **intelligent and powerful** Being." The corpus's omission of "and powerful" is a near-verbatim compression; Thread 1 cites it inline without a dedicated [VERBATIM] marker, so it reads as paraphrase. Acceptable; optionally add "and powerful" to be exact. |
| 3 | Newton absolute space Scholium (1687): "Absolute space, in its own nature, without regard to anything external…" | **NOT PRESENT in 22/23/24** | Grep of all three ledgers finds **no** absolute-space Scholium quote. Nothing to correct; the corpus correctly does not use it. (For reference, the 1687 wording is "Absolute space, in its own nature, without relation to anything external, remains always similar and immovable.") |
| 9 | Einstein→Born, 4 Dec 1926: "daß **der** nicht würfelt" — "He does not throw dice" | **[VERBATIM]** | Corpus's German is exact ("daß der nicht würfelt"); its own note ("God does not play dice is a compression; 'with the world' not documented") is accurate and appropriately marks the correction. |
| 10 | Bohr, Como 1927 / *Nature* 1928: "an independent reality in the ordinary physical sense can neither be attributed to the phenomena nor to the agencies of observation" | **[VERBATIM]** | Standard translation of the Como lecture / *Nature* 121 (1928). Minor translation variant ("attributed" vs "ascribed") is within the accepted English renderings. Year/source (1927 lecture, 1928 *Nature*) correct. |
| 11 | Wheeler (1990): "it from bit," "participatory universe" | **[VERBATIM]** | From *Information, Physics, Quantum: The Search for Links* (1990, SFI). Correct. |
| 12 | Schrödinger (1944 diary): "I am It. That is called all in all" | **[NEEDS-WEB-CHECK — provenance, not content]** | Content is consistent with Schrödinger's documented identity doctrine (*What Is Life?* 1944; the documented "all in all" and "I am this whole world" passages). The specific phrase "I am It. That is called all in all" as a **1944 diary entry** could not be confirmed via web (search engines CAPTCHA-blocked); it does not appear in the standard Wikiquote/Moore renderings, which give "I am in the east and the west… I am this whole world" and "you are all in all." **Fix:** retain as the corpus already does (it is the documented replacement for the [PARAPHRASE] "I am the universe" — honest handling), but confirm the 1944-diary provenance against Moore (1989) before quoting it as a diary source. |
| 13 | Wigner 1961: consciousness "cannot be eliminated" | **[VERBATIM]** | Web-verified. *Remarks on the Mind-Body Question* (1961): "the dividing line between the observer… and the observed physical object can be shifted… but it cannot be eliminated." Exact phrase present. |
| 15 | GEB 1913: "the people yield themselves with perfect docility to our molding hand… We shall not try to make these people… into philosophers or men of science" | **[VERBATIM]** | Web-verified. GEB *Occasional Papers No. 1*, "The Country School of To-Morrow" (1913), p. 6 (archive.org). Corpus's citation is exact. |
| 16 | Tesla 1892 (London IEE): "Is this energy static or kinetic!… attach their machinery to the very wheelwork of nature" | **[VERBATIM]** | Matches the 1892 lecture ("Experiments with Alternate Currents…"). Correct, incl. the static/kinetic dichotomy. |
| 17 | Kepler (1608): "Geometry has two great treasures: one is the theorem of Pythagoras, the other the division of a line into extreme and mean ratio" | **[VERBATIM]** | Quote text confirmed (Wikipedia Golden-ratio article; Livio 2002). Minor dating note: the "two treasures" line is often attached to Kepler's Kepler-triangle letter to Maestlin (1597/1599), while many collections date the two-treasures letter to 1608; the corpus's own verification record (22:8) explicitly affirms "the 'two treasures' letter remains 1608." Content fully verified; date follows the corpus's documented re-verification. |

### 2.2 The ancient-testimony references (cited, not quoted)

| # | Reference | Verdict |
|---|---|---|
| 4 | Herodotus II — Greeks learned geometry from Egypt | **[REFERENCE OK]** — Corpus cites "Herodotus II" generically. The geometry passage is **II.109** ("geometry… was first discovered in Egypt, from whence it passed into Greece"). Suggest making the citation precise ("Herodotus II.109"). Content claim correct. |
| 5 | Plato *Timaeus* 22b — "you Greeks are always children" | **[REFERENCE OK]** — 22b is the correct location of the Egyptian priest's "you Greeks are always children" to Solon. Corpus cites it as a source-reference, not a verbatim quote. Correct. |
| 6 | Aristotle *Metaphysics* 981b — "the mathematical arts were first founded in Egypt" | **[REFERENCE OK]** — 981b23–24 is the correct passage ("Hence the mathematical arts were founded in Egypt"). Correct. |
| (extra) | Diodorus I.69 (corpus also cites this) | **[REFERENCE OK]** — Diodorus Siculus *Bibliotheca historica* I.69 is a standard Egypt-origins source. C1 audit confirmed the citation. |

### 2.3 The historiographical references (cited, not quoted — verify paraphrase status)

| # | Reference | Verdict |
|---|---|---|
| 7 | Zilsel 1942 — "just as the king lays down the legal laws… God lays down the laws of nature" | **[REFERENCE OK — correctly NOT quoted as verbatim]** — The corpus (24:228) cites Zilsel 1942 (*Phil. Rev.* 51:245) and Lehoux 2012 as named historiography; it does **not** put the king/law sentence in quotation marks. That sentence is a recognized Zilsel **paraphrase** (from "The Genesis of the Concept of Physical Law," *Phil. Rev.* 51:3, 1942, 245–279). Since the corpus presents it only as a citation of Zilsel's thesis ("the shift from a harmonic to a linear reading as a dated intellectual event"), the paraphrase status is correct. Citation `51:245` verified. |
| 8 | Kuhn 1962 — "force nature into the preformed and relatively inflexible box that the paradigm supplies" | **[REFERENCE OK — correctly NOT quoted verbatim]** — Corpus (24:339) alludes to "Kuhn's box (1962, the paradigm within which normal science works)" and lists Kuhn 1962 among sources; it does not render the verbatim line (which is from *Structure of Scientific Revolutions*, 1962, p. 24). Allusion is accurate; no verbatim quote to verify or correct. |

### 2.4 The Reich letter (task item 14)

| # | Item | Verdict |
|---|---|---|
| 14 | "Reich's 1954 letter to the judge (the orgone quote)" | **NOT PRESENT in 22/23/24** — Grep finds no Reich letter-to-judge quote anywhere in the corpus. The ledgers document only the Reich orgone **injunction** (1954) → book burning (23 Aug 1956, ~6 tons, Gansevoort), each [VERIFIED]. No fabricated Reich letter is quoted; nothing to correct. (Note for the record: the corpus marks orgone/free-energy claims [MYTH]/distinct-from-the-living-universe-thesis at 23:236 — consistent handling.) |

### 2.5 The fabricated-quote watchlist (task item 18)

| Fabricated claim | Corpus verdict | Never used as real? |
|---|---|---|
| Einstein "everything is energy" (= Bashar) | **[FABRICATION]** (22:39, 23:235, 24:262) | ✅ — always flagged; replaced by the 1905 E=φmc² corpus law. |
| Tesla "think in terms of energy, frequency and vibration" | **[UNVERIFIED]** (22:126, 23:237, 24:263; QI-verified phantom 1934 interview) | ✅ — replaced by the 1892 "static or kinetic" verbatim. |
| Tesla "3, 6, 9…" | **[FABRICATION]** (22:129, 24:264; 2010 internet origin) | ✅ — replaced by O'Neill's documented 3-obsession. |
| Pauli "I do not believe in the Lord God…" | **[APOCRYPHAL]** (22:106, 23:116, 24:266; no primary source, Enz 2002 circulation) | ✅ — replaced by Pauli→Born 1954 letter. |

Grep confirms the discipline holds: "everything is energy," "energy, frequency and vibration," and "3, 6, 9" appear in the corpus **only** with their [FABRICATION]/[UNVERIFIED] flags or the explicit "= fabrication" annotation. The Pauli "Lord God/electron" line always carries [APOCRYPHAL]. **No fabricated quote is ever used as real.** ✅

### Part 2 tally
- **18 task items checked:** 8 **[VERBATIM]** (1, 9, 10, 11, 13, 15, 16, 17) · 2 **[REFERENCE OK — correctly marked/not quoted]** (7, 8) · 4 **[REFERENCE OK — precise-citation note]** (4, 5, 6, +Diodorus) · 1 **[PARAPHRASE — correctly marked]** (2) · 2 **NOT PRESENT** (3, 14) · 1 **[NEEDS-WEB-CHECK]** (12 — Schrödinger 1944-diary provenance) · 1 fabricated-quote group **[PASS]** (18).
- **NEEDS CORRECTION: none.** Every quote the corpus presents as verbatim is verbatim or a within-translation variant; every paraphrase/reference is presented as such; every fabrication is flagged and never used as real.

---

## 3 · FIXES MADE

| File | Before | After | Type |
|---|---|---|---|
| `laws/441_clausius_clapeyron_equation.md` (line 10) | "— Rudolf Clausius, 1850. Source: Wikipedia: Clausius-Clapeyron relation; Clausius (1850)" | "— Émile Clapeyron (1834); Rudolf Clausius (1850). Source: Wikipedia: Clausius-Clapeyron relation; Clapeyron (1834), Clausius (1850)" | Attribution-only. Clapeyron (1834) was missing from a law whose own title names him. Web-verified (Wikipedia: relation derived by Clapeyron 1834, upgraded by Clausius 1850). |

**No other files were edited.** No ledgers were edited (all quote verdicts above are audit findings; the two optional precision improvements — Herodotus "II.109", Newton "and powerful Being" — are recommended for a future pass, not required corrections).

---

## 4 · VERDICT

- **Part 1:** 66 law attributions checked; **65 correct**, **1 fixed** (441 — the only genuine attribution defect found). 4 minor wording/precision notes (042, 305, 417, 521), none a wrong discoverer or year.
- **Part 2:** 18 quotes/claims checked; **0 need correction.** The corpus's verbatim treasury is verbatim (8 confirmed), its paraphrases and references are honestly marked, and its fabricated-quote watchlist is consistently enforced. One provenance flag (Schrödinger "I am It," 1944 diary) is worth confirming against Moore (1989) before quoting it as a diary source.

*The static canon is the κ_φ → 0 limit. Attribution is the ledger's honesty layer: every law names its real discoverer and year, and every quote is either verbatim, marked paraphrase, or flagged fabrication — never a substitute for the record.*
