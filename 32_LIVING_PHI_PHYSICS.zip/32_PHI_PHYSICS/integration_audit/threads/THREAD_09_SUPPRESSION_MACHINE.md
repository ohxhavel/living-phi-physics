# THREAD 09 — THE SUPPRESSION MACHINERY

**Status:** This thread survives as the accumulated-findings summary only; its full content is carried in `STATIC_WORLDVIEW_THREAD_15_THE_LEDGER.md` (§6 verdict scorecard) and the ledger verdict tables.

**Accumulated findings (documented, from the 15-thread investigation):**

1. **Wilhelm Reich** — FDA injunction (1954, lawful regulatory action over an unapproved device; Reich refused to appear); contempt (1956, 2 years); **documented book burning of ~6 tons at the Gansevoort incinerator, 25th St, NYC, 23 Aug 1956** — "one of the worst examples of censorship in U.S. history"; died 3 Nov 1957 of myocardial insufficiency at Lewisburg (natural death; a parole hearing was pending — no appeal). Einstein's 1941 test found a temperature-gradient artifact. Archives at Harvard's Countway Library unsealed 2007. Both-sides myths named: "government killed Reich" (myth) and "Reich was simply a fraud" (oversimplification — the biblioclasm was extreme, the science was rejected).
2. **Velikovsky** — the 1950 Macmillan textbook-boycott threat by Harlow Shapley is documented; the book transferred to Doubleday and became a bestseller. His physics was genuinely wrong (conservation violations); he was never silenced — AAAS 1974 symposium, Sagan's critique. Suppression of a channel + valid skepticism, both documented.
3. **McCarthy-era physicists** — Condon (HUAC 1948, "weakest links"), Frank Oppenheimer (fired Minnesota 1949), Weinberg (fired 1951, acquitted 1953, never reinstated), Peters (left for India 1951), Bohm (passport confiscated, Brazil), Morrison (curtailed). Wang 1999 (*American Science in an Age of Anxiety*): "stifling effects of anticommunist ideology on the politics of science." Targets were political, not "living physics."
4. **Gatekeeping** — peer review (1665+), >90% journal rejection, file-drawer bias, the 2015 replication crisis (36% of psychology studies), the Matthew effect (Merton 1968; Bol 2018: >2× funding), Kuhn's paradigm box (SSR 1962, p. 24).
5. **The establishment fails both ways** — right about cold fusion/polywater/N-rays; wrong about Wegener/craters/H. pylori/noble gases. The machinery is real but not a monolith.
6. **The "Two Cultures"** — Snow 1959; the Sokal affair 1996 as two-sided gatekeeping.

*See also: the ledger's verdict scorecard (Part VII of 23_THE_SYSTEM_OF_THE_FABRICATION.md).*
