# C1 — PEOPLE LEDGER AUDIT
## Every name in the history ledger — spelling, dates, role, claim, source

**Auditor:** Agent C1 of 10 (HARDENING PASS) · **Date:** 2026-08-07 · **Scope:** the people in `24_THE_GEOMIC_LEDGER.md` (§5 History, §6 Watchlist, §8 Skeptic), `22_THE_HISTORICAL_INVESTIGATION.md`, `23_THE_SYSTEM_OF_THE_FABRICATION.md`, and `00_NUMBERS_INDEX.md` §5 (History Ledger Numbers)

**Method:** full read of the four ledger documents; corpus-wide grep for every name on the C1 key-people list (all file types, including `laws/`, `sim/`, `validation/`, `expansion_log/`, `graphify-out/`); live web verification attempted for the highest-risk items (Wikipedia: Yuri Knorozov — succeeded; Watkiss Lloyd — no article). Everything else verified against internal knowledge and **flagged where not independently re-verified.** No main document was edited — audit only.

**Verdict legend.** **OK** = spelling, person, role, and year check out · **CORRECTED** = the ledger carries a wrong/missing spelling or attribution that must be fixed · **NEEDS SOURCE** = person/claim is correct as far as known but the ledger attaches no checkable citation (or the exact year/book is unconfirmed here) · **ABSENT** = on the C1 checklist but not present in any ledger document (no action needed in 32_PHI_PHYSICS).

---

## 1 · SUMMARY

| Count | Value |
|---|---|
| Distinct names checked in the ledger documents | **148** |
| Verified correct (OK) | **133** |
| Need spelling/attribution correction (**CORRECTED**) | **3 names across 7 lines** |
| Need a named source / year confirmation (**NEEDS SOURCE**) | **14 items** |
| Key-list names checked but ABSENT from the ledger docs | **26** |

**The ledger's people-register is in strong shape.** The money trail correctly separates **John D. Rockefeller Sr.** (UChicago/GEB/RF) from **John D. Rockefeller Jr.** (Oriental Institute/Met); the APS-president roll (Fermi 1953, Bethe 1954, Wigner 1956, Uhlenbeck 1959, Weisskopf 1960) is exactly right; the Knorozov claim (1952 phonetic key, resisted by J. Eric S. Thompson, vindicated post-1975) is confirmed against Wikipedia. The **three real defects** are spelling inconsistencies: **Knorozov** (twice written "Knorosov" in doc 23), **Lemaître** (accent dropped in 22/23 and one law file), and **J. Eric Thompson** (missing middle initial "S." in doc 24).

---

## 2 · THE PEOPLE TABLE (all names in the ledger docs)

### 2.1 The money and the foundations (docs 22 T1, 23 §II, 24 §5.1, 00 §5.1)

| Name (as in ledger) | Correct spelling | Life dates | Role claimed | Year | Verdict |
|---|---|---|---|---|---|
| Rockefeller (Standard Oil) | John D. Rockefeller Sr. | 1839–1937 | University of Chicago $600K + $10M; GEB ~$180M; RF chartered — the research-university model | 1890/1910; GEB 1903–64; RF 1913 | **OK** — correct person for all three institutions |
| Rockefeller Jr. | John D. Rockefeller Jr. | 1874–1960 | Oriental Institute funding (Breasted) | 1919 | **OK** — correctly distinguished from Sr. |
| Carnegie (US Steel) | Andrew Carnegie | 1835–1919 | Carnegie Institution of Washington $10M → Mount Wilson → Hubble 1929 | 1902 | **OK** |
| Carnegie | Andrew Carnegie | — | Carnegie Corporation of NY $135M, "largest trust of its era" | 1911 | **OK person; NEEDS SOURCE (figure)** — commonly cited initial endowment $125M (135 cited by some) |
| Carnegie | Andrew Carnegie | — | CFAT → Carnegie unit/credit hour, TIAA, GRE, ETS | 1905 | **OK** |
| Ford | Henry Ford / Edsel Ford | 1863–1947 / 1893–1943 | Ford Foundation; 90% of Ford Motor by 1947 | 1936/1950 | **OK** — neither named individually; suggest "Henry & Edsel Ford" |
| McCloy | John J. McCloy | 1895–1989 | CIA channel under McCloy at Ford Foundation | 1958–65 | **OK** — correct person and dates |
| Weaver | Warren Weaver | 1894–1978 | RF Natural Sciences Division director; pivot to molecular biology | 1932–55 | **OK** — exact years correct |
| Gates | Frederick Taylor Gates | 1853–1929 | RF/GEB secretary; author of the GEB "molding hand" document (Occasional Papers No. 1, 1913) | 1913 | **OK claim, ABSENT as a name** — the quote is attributed to "GEB" at 24:186/188/367 but Gates is never named; recommend naming him |
| Guggenheim | Simon Guggenheim | 1867–1941 | John Simon Guggenheim Memorial Foundation; ~$400M / 19,000 fellows | 1925 | **OK** |
| Sloan | Alfred P. Sloan | 1875–1966 | MIT / Sloan-Kettering | 1945/1950 | **OK** |
| Harriman | Mary Williamson Harriman (Mrs. E. H. Harriman) | 1851–1932 | Cold Spring Harbor ERO funding (Carnegie+Rockefeller+Harriman) | 1910–39 | **OK** — "Harriman" alone is ambiguous; recommend naming her |
| Bush | Vannevar Bush | 1890–1974 | Closed the ERO 1939; NSF (Bush/Kilgore) 1950 | 1939/1950 | **OK** |
| Kilgore | Harley M. Kilgore | 1893–1956 | NSF "basic-only, defense-mission" settlement with Bush | 1950 | **OK** |
| Templeton | John Templeton (Sir John) | 1912–2008 | Templeton Foundation; ~$150M/yr, $3.6B endowment | 2005– | **OK** |
| J.P. Morgan | J. Pierpont Morgan | 1837–1913 | The Met Egyptian dept via partage | 1906 | **OK** |
| Carnarvon | George Herbert, 5th Earl of Carnarvon | 1866–1923 | Tutankhamun dig; "Rothschild settlement" (wife Almina, Rothschild) | 1922 | **OK person; NEEDS SOURCE (figure)** — the £500,000 figure needs a named source |
| Davis | Theodore M. Davis | 1838–1915 | ~30 Valley-of-the-Kings tombs; bequeathed to Met | 1902–13 | **OK** |
| Harkness | Edward S. Harkness | 1874–1940 | Bought the Carnarvon collection for the Met | 1926 | **OK** |
| Budge | E. A. Wallis Budge | 1857–1934 | Amarna tablet smuggling "by means of bribery" | 1880s–90s | **OK** — source = his *By Nile and Tigris* (per A7) |
| Fulbright | J. William Fulbright | 1905–1995 | Fulbright Act; soft power | 1946 | **OK** |
| Elgin (Lord) | Thomas Bruce, 7th Earl of Elgin | 1766–1841 | Elgin Marbles purchase £35,000 (vote 82–30) | 1816 | **OK** |

### 2.2 The institutions and the gatekeepers (docs 22 T4/9/15, 23 §III–IV, 24 §5.2)

| Name (as in ledger) | Correct spelling | Life dates | Role claimed | Year | Verdict |
|---|---|---|---|---|---|
| Eliot | Charles W. Eliot | 1834–1926 | NEA Committee of Ten; "same way and to the same extent to every pupil" | 1892 (report 1893) | **OK** |
| Brigham | Carl C. Brigham | 1890–1943 | SAT; documented eugenic intent (*A Study of American Intelligence* 1923); recanted 1930 | 1923/1926/1930 | **OK** |
| Terman | Lewis M. Terman | 1877–1956 | Army Alpha/Beta; documented eugenicist | 1917 | **OK** |
| Yerkes | Robert M. Yerkes | 1876–1956 | Army Alpha/Beta | 1917 | **OK** |
| Thorndike | Edward L. Thorndike | 1874–1949 | documented eugenicist | — | **OK** |
| Gates (Core) | Bill Gates / Gates Foundation | b. 1955 | Common Core funding; 71% districts cut non-tested subjects (CEP 2006) | 2010 | **OK person** — but flag: different "Gates" from Frederick Taylor Gates; add "Bill" |
| Kozol | Jonathan Kozol | b. 1936 | "cognitive decapitation" (NCLB/Common Core) | 2001/2010 | **OK person; NEEDS SOURCE** for the "cognitive decapitation" phrase |
| Dever | William G. Dever | b. 1933 | ASOR/Albright school "Prove the Bible" → "all overturned" | 1900/1993 | **OK** |
| Albright | William Foxwell Albright | 1891–1971 | ASOR/Albright school (eponym) | 1900 | **OK** |
| Thomas | Cyrus Thomas | 1825–1910 | Smithsonian BAE debunked its own Mound Builder myth | 1879–94 (report 1894) | **OK** — 12 years/$60,000 consistent with standard accounts |
| de Vaux | Roland de Vaux | 1903–1971 | École Biblique team; DSS Cave 4 ~80% unpublished until 1991 | 1947–91 | **OK** |
| Sarton | George Sarton | 1884–1956 | Isis 1912 / HSS 1924; canonized Western history (Carnegie-funded 1919–48); defended Islamic science | 1912/1924 | **OK** |
| Kline | Morris Kline | 1908–1992 | "scrawling of children" on non-Western math | 1962 | **OK person; NEEDS SOURCE (book/year)** — verify *Mathematics: A Cultural Approach* (1962) vs *Mathematics in Western Culture* (1953) |
| Bamberger | Louis Bamberger | 1855–1944 | IAS founded | 1930 | **OK** |
| Flexner | Abraham Flexner | 1866–1959 | IAS "pure thought" institute | 1930 | **OK** |
| Zacharias | Jerrold Zacharias | 1905–1986 | PSSC curriculum | 1956 | **OK** |
| Cowan | George Cowan | 1920–2012 | SFI co-founder | 1984 | **OK** |
| Gell-Mann | Murray Gell-Mann | 1929–2019 | SFI co-founder; Nobel 1969 | 1984 | **OK** |
| Tegmark | Max Tegmark | b. 1967 | FQxI co-founder (with Aguirre); 2000 brain-decoherence paper | 2005 | **OK** |
| Aguirre | Anthony Aguirre | b. 1970 | FQxI co-founder | 2005 | **OK** |
| Lazaridis (Perimeter) | Mike Lazaridis | b. 1961 | Perimeter Institute $100M endowment | 1999 | **OK** — **but disambiguate from Iosif Lazaridis (below)**; both appear bare as "Lazaridis" |
| Cahill | Reginald T. Cahill | — | "Process Physics" (Flinders) | — | **OK** |
| Haidara | Abdel Kader Haidara | b. 1964 | Timbuktu rescue, 350,000 manuscripts | 2012–13 | **OK** |
| Snow | C. P. Snow | 1905–1980 | "Two Cultures" | 1959 | **OK** |
| Weinberg (Alvin) | Alvin M. Weinberg | 1915–2006 | coined "Big Science" | 1961 | **OK** |

### 2.3 The documented suppressions (docs 22 T5, 23 §VI–VII, 24 §5.3, 00 §5.2)

| Name (as in ledger) | Correct spelling | Life dates | Role claimed | Year | Verdict |
|---|---|---|---|---|---|
| Reich | Wilhelm Reich | 1897–1957 | Book burning at Gansevoort incinerator, 25th St; ~6 tons | 23 Aug 1956 | **OK** |
| Velikovsky | Immanuel Velikovsky | 1895–1979 | *Worlds in Collision* pressure; moved to Doubleday | 1950 | **OK; NEEDS SOURCE** (ledger EVIDENCE cell is bare "[VERIFIED]"; A7 already flagged) |
| Shapley | Harlow Shapley | 1885–1972 | Led the academia pressure to drop Velikovsky's book at Macmillan | 1950 | **OK** — correct person and action (standard account); pair with Velikovsky source fix |
| Condon | Edward U. Condon | 1902–1974 | McCarthy-era clearance denied | 1947–54 | **OK** |
| F. Oppenheimer | Frank Oppenheimer | 1912–1985 | Fired after HUAC | 1949 | **OK** |
| Weinberg (Joseph) | Joseph Weinberg | 1923–c.2005 | HUAC target | 1951 | **OK** |
| Peters | Bernard Peters | 1910–1993 | Denied clearance; left for India | 1951 | **OK** |
| Bohm | David Bohm | 1917–1992 | Passport confiscated Dec 1951; fled to Brazil; causal interpretation 1952 | 1951/1952 | **OK** — Wang 1999 cited |
| Knorozov | Yuri Knorozov | 1922–1999 | Correct phonetic Mayan key 1952; resisted; vindicated post-1975 | 1952 → post-1975 | **OK claim** (web-confirmed) — **CORRECTED: spelling** "Knorosov" at 23:133, 23:183, 23:206 → "Knorozov" |
| Thompson | J. Eric S. Thompson | 1898–1975 | Led the Anglo-American resistance to Knorozov | 1952 → 1975 | **OK claim** (web-confirmed) — **CORRECTED: add "S."** at 24:221 ("J. Eric Thompson" → "J. Eric S. Thompson") |
| Josselson | Michael Josselson | 1908–1978 | CCF executive secretary | 1950–67 | **ABSENT** — never named in the ledger; optional enrichment under the CCF row (24:193, 23:68) |
| Milik | Józef Tadeusz Milik | 1922–2006 | DSS editorial team | 1950s–60s | **ABSENT** — optional under the DSS row |
| Strugnell | John Strugnell | 1930–2007 | DSS editor-in-chief | 1984–90 | **ABSENT** — optional |
| Cross | Frank Moore Cross | 1921–2012 | DSS editorial team | 1950s–70s | **ABSENT** — optional |
| Skehan | Patrick W. Skehan | 1909–1980 | DSS editorial team | 1950s–70s | **ABSENT** — optional |

### 2.4 The documented corrections and the science (docs 22, 24 §5.4, 00 §5.3)

| Name (as in ledger) | Correct spelling | Life dates | Role claimed | Year | Verdict |
|---|---|---|---|---|---|
| Herodotus | Herodotus | c.484–425 BCE | "Greek miracle" overwrote Greeks' own testimony (Herodotus II) | 5th c. BCE | **OK** |
| Plato | Plato | c.428–348 BCE | *Timaeus* 22b | — | **OK** |
| Aristotle | Aristotle | 384–322 BCE | *Metaphysics* 981b | — | **OK** |
| Diodorus | Diodorus Siculus | c.90–30 BCE | *Bibliotheca historica* I.69 | 1st c. BCE | **OK** |
| Renan | Ernest Renan | 1823–1892 | Coined "le miracle grec"; Aryan-race theorist | 1883 | **OK person; NEEDS SOURCE (year)** — the phrase is documented to Renan; confirm 1883 (*Souvenirs d'enfance et de jeunesse*) vs 1890 (*L'Avenir de la science*) |
| Zilsel | Edgar Zilsel | 1891–1944 | "The Genesis of the Concept of Physical Law," *Phil. Rev.* 51:245 | 1942 | **OK** — citation verified correct (Phil Rev 51, 1942, 245–279) |
| Lehoux | Daryn Lehoux | b. 1968 | harmony→law historiography | 2012 | **OK** |
| Noether | Emmy Noether | 1882–1935 | Noether's theorem; symmetry ↔ conservation; Einstein's 1935 tribute; never a full professor | 1918 | **OK; NEEDS SOURCE** for the Einstein 1935 tribute and "never a full professor" (A7 flagged) |
| Planck | Max Planck | 1858–1947 | S = k log W (not Boltzmann); named k; 1900–01 | 1900–01 | **OK** |
| Einstein | Albert Einstein | 1879–1955 | Λ 1917 "static"; Leiden 1920 ether; tribute to Noether 1935 | 1917/1920 | **OK** |
| Lorentz | Hendrik Lorentz | 1853–1928 | contraction kept the aether | 1892 | **OK** |
| Michelson | Albert A. Michelson | 1852–1931 | Nobel 1907 for optical instruments, not aether; searched to death | 1907 | **OK** |
| Morley | Edward W. Morley | 1838–1923 | M–M 1887 null result | 1887 | **OK** |
| Millikan | Robert A. Millikan | 1868–1953 | ether in American pedagogy until 1927 | — | **OK** |
| Gibbs | J. Willard Gibbs | 1839–1903 | *On the Equilibrium of Heterogeneous Substances* | 1875–78 | **OK** |
| Clausius | Rudolf Clausius | 1822–1888 | "energy constant, entropy maximum" | — | **OK** |
| Maxwell | James Clerk Maxwell | 1831–1879 | "only one man who could understand Gibbs" | — | **OK** |
| Boltzmann | Ludwig Boltzmann | 1844–1906 | Martyrdom myth debunked; won Lübeck 1895; suicide = health | — | **OK** |
| Loschmidt | Josef Loschmidt | 1821–1895 | reversibility objection | 1876 | **OK** |
| Zermelo | Ernst Zermelo | 1871–1953 | recurrence objection 1896; axiom of empty set 1908 | 1896/1908 | **OK** |
| Mach | Ernst Mach | 1838–1916 | rejected atoms ("I don't believe that atoms exist!") | 1897 | **OK** |
| Ostwald | Wilhelm Ostwald | 1853–1932 | Lübeck debate (energetics vs atomism) | 1895 | **OK** |
| Sommerfeld | Arnold Sommerfeld | 1868–1951 | "the bull was victorious" | 1895 | **OK** |
| Perrin | Jean Perrin | 1870–1942 | vindicated atoms | 1908 | **OK** |
| Eddington | Arthur Eddington | 1882–1944 | coined "arrow of time" | 1927/28 | **OK** |
| Prigogine | Ilya Prigogine | 1917–2003 | Nobel 1977 in **Chemistry**; dissipative structures | 1977 | **OK** |
| Stengers | Isabelle Stengers | b. 1949 | *Order Out of Chaos* co-author | 1984 | **OK** |
| Smolin | Lee Smolin | b. 1955 | *Time Reborn* 2013; heat-death critique | 2013 | **OK** |
| Cortês | Marina Cortês | — | Cortês–Smolin time papers | 2014/18 | **OK** |
| Elitzur | Avshalom Elitzur | b. 1957 | "time is real" minority | 2016 | **OK** |
| Barbour | Julian Barbour | b. 1937 | "time is an illusion" | — | **OK** |
| Rovelli | Carlo Rovelli | b. 1956 | relational QM | — | **OK** |
| Penrose | Roger Penrose | b. 1931 | Orch OR; Nobel 2020 (singularity theorems) | 2020 | **OK** |
| Hameroff | Stuart Hameroff | b. 1947 | Orch OR (law 1440; history docs name only Penrose) | 1996 | **OK** |
| Koch | Christof Koch | b. 1956 | IIT; 2023 adversarial collab won 2/3 by IIT; conceded 1998 wine bet | 2023 | **OK** |
| Tononi | Giulio Tononi | b. 1960 | IIT | — | **OK** |
| Chalmers | David Chalmers | b. 1966 | hard problem / panpsychism (philosophy only) | — | **OK** |
| Goff | Philip Goff | b. 1978 | panpsychism | 2017 (OUP vol.) | **OK** |
| Strawson | Galen Strawson | b. 1952 | panpsychism | 2006 | **OK** |
| Nagel | Thomas Nagel | b. 1937 | "Panpsychism" | 1979 | **OK** |
| Ursachi | Andrei Ursachi | — | φ-organized α/θ ratio, Phi Coupling Index, N=320, 80.0% | 2026 | **NEEDS SOURCE (external)** — 2026 publication cannot be independently confirmed from this environment; the corpus claims live PubMed verification (PMID 41859481). Re-verify on PubMed at release |
| Coldea | Radu Coldea | b. 1972 | E8/golden-ratio quasiparticle masses at quantum criticality, *Science* 327:177 | 2010 | **OK** — the E8 Ising-chain experiment in CoNb₂O₆ (Oxford); "golden-ratio masses" is an accurate description; replication claim (Zhang et al., BaCo₂V₂O₈) consistent with the 2021 literature |
| McKemmish | Laura K. McKemmish | — | no quantum in the brain (with Tegmark) | 2009 | **OK** |
| Wigner | Eugene Wigner | 1902–1995 | consciousness "cannot be eliminated" | 1961 | **OK** |
| Wheeler | John Archibald Wheeler | 1911–2008 | "it from bit"; "participatory universe" | 1990 | **OK** |
| Pauli | Wolfgang Pauli | 1900–1958 | Pauli–Jung *unus mundus*; "Lord God/electron" quote apocryphal | 1952 | **OK** |
| Jung | Carl Jung | 1875–1961 | Pauli–Jung collaboration | 1952 | **OK** — note the *Atom and Archetype* letters span 1932–58; 1952 is the peak-exchange year, fine |
| Schrödinger | Erwin Schrödinger | 1887–1961 | cat 1935 (reductio); "damned quantum jumping" 1926; "I am the universe" = paraphrase | 1935/1926 | **OK** |
| Born | Max Born | 1882–1970 | Einstein→Born 1926 "der nicht würfelt"; Pauli→Born 1954 | 1926/1954 | **OK** |
| Bohr | Niels Bohr | 1885–1962 | Como 1927 / *Nature* 1928; Solvay photon-box rests on his 1949 memoir | 1927/28 | **OK** |
| Heisenberg | Werner Heisenberg | 1901–1976 | coined "Copenhagen interpretation" ~1955 | ~1955 | **OK** (Howard 2004 cited) |
| Howard | Don Howard | — | "Who Invented the Copenhagen Interpretation?" | 2004 | **OK** |
| Mermin | N. David Mermin | b. 1935 | coined "shut up and calculate," *Physics Today* 42(4):9, 1989; corrected attribution 2004 | 1989 | **OK** |
| Feynman | Richard Feynman | 1918–1988 | **not** the coiner — correctly corrected by the ledger | — | **OK** |
| Bell | John Stewart Bell | 1928–1990 | Bell 1964; *Omni* 1988 quote | 1964/1988 | **OK** |
| Aspect | Alain Aspect | b. 1947 | Bell-violation experiments; Nobel 2022 | 1982/2022 | **OK** |
| Clauser | John Clauser | b. 1942 | Bell-violation experiments; Nobel 2022 | 2022 | **OK** |
| Zeilinger | Anton Zeilinger | b. 1945 | Bell-violation experiments; Nobel 2022 | 2022 | **OK** |
| Hensen | Bas Hensen | — | loophole-free Bell | 2015 | **OK** |
| Kepler | Johannes Kepler | 1571–1630 | "two treasures" 1608; Fibonacci→φ 1609; third law in *Harmonices Mundi* 1619 | 1608/1609/1619 | **OK** |
| Maestlin | Michael Maestlin | 1550–1631 | recipient of both Kepler letters | 1608/1609 | **OK** |
| Fibonacci | Leonardo of Pisa (Fibonacci) | c.1170–1250 | *Liber Abaci* 1202 (zero + rabbit problem); did **not** invent/link the sequence | 1202 | **OK** |
| Simon Jacob | Simon Jacob | c.1510–1564 | first to note the sequence–φ link | 16th c. | **OK** |
| Ohm (Martin) | Martin Ohm | 1792–1872 | "goldener Schnitt" | 1835 | **OK** |
| Barr | Mark Barr | 1871–1950 | coined "phi" | ~1909 | **OK** |
| Euclid | Euclid | fl. c.300 BCE | *Elements*; no zero | c.300 BCE | **OK** |
| Brahmagupta | Brahmagupta | c.598–c.668 | first zero arithmetic (*Brāhmasphuṭasiddhānta* 18.30–34) | 628 CE | **OK** |
| Bhāskara II | Bhāskara II | 1114–1185 | division by zero → infinite | 12th c. | **OK** |
| Gerbert / Sylvester II | Gerbert of Aurillac | c.946–1003 | Hindu-Arabic numerals to Europe | 980s | **OK** |
| Descartes | René Descartes | 1596–1650 | *La Géométrie* 1637; equations = 0 | 1637 | **OK** |
| Cauchy | Augustin-Louis Cauchy | 1789–1857 | "has zero as its limit" | 1821 | **OK** |
| von Neumann | John von Neumann | 1903–1957 | 0 := ∅ | 1923 | **OK** |
| Nothaft | C. Philipp E. Nothaft | b. 1982 | zero-as-satanic = "dark medievalism"; 1299 Florence statute secular | 2020 | **OK** — corpus uses surname only; correct full name noted (the task's "David Nothaft" is wrong — it is **C. Philipp E. Nothaft**) |
| Seife | Charles Seife | b. 1972 | *Zero: The Biography of a Dangerous Idea* | 2000 | **OK** |
| Pacioli | Luca Pacioli | 1447–1517 | *De Divina Proportione* (comp. 1498, pub. 1509) | 1498/1509 | **OK** |
| Piero della Francesca | Piero della Francesca | c.1415–1492 | Pacioli partly plagiarized him | — | **OK** |
| Leonardo | Leonardo da Vinci | 1452–1519 | illustrated Pacioli; Vitruvian Man (not φ) | — | **OK** |
| Vitruvius | Vitruvius | c.80–15 BCE | Vitruvian fractions (1/4…1/10, thirds) | 1st c. BCE | **OK** |
| Murtinho | Vítor Murtinho | — | φ-construction fails the Vitruvian Man drawing | 2015 | **OK person; NEEDS SOURCE** — not independently re-verified here; keep the citation |
| Watkiss-Lloyd | William Watkiss Lloyd (per ledger) | 1813–1893 | Parthenon 4:9 ratio | 1863 | **NEEDS SOURCE** — I could not locate a "Watkiss Lloyd 1863" Parthenon study online (no Wikipedia article); the person is plausibly the classicist William Watkiss Lloyd, but the year/claim needs a named source |
| Zeising | Adolf Zeising | 1810–1876 | Parthenon φ claim | 1854 | **OK** — *Neue Lehre von den Proportionen* 1854 |
| Markowsky | George Markowsky | b. 1948 | "Misconceptions about the Golden Ratio" | 1992 | **OK** |
| Livio | Mario Livio | b. 1945 | *The Golden Ratio* (2002); Pacioli aesthetic reading = 1799 error | 2002 | **OK** |
| Newton | Isaac Newton | 1643–1727 | *hypotheses non fingo* 1713; divine governor; clockwork built over him | 1713/1687 | **OK** |
| Voltaire | Voltaire | 1694–1778 | built the "clockwork Newton" | 1738 | **OK** |
| Euler | Leonhard Euler | 1707–1783 | "more responsible for Newtonian mechanics than Newton" | — | **OK** |
| Laplace | Pierre-Simon Laplace | 1749–1827 | demon 1814; "no need of that hypothesis" = apocryphal as told | 1814 | **OK** |
| Gamow | George Gamow | 1904–1968 | Einstein "biggest blunder" (secondhand) | — | **OK** |
| Hubble | Edwin Hubble | 1889–1953 | proved expansion | 1929 | **OK** |
| Lemaître | Georges Lemaître | 1894–1966 | 1927 expanding-solution; Einstein called his work "abominable" | 1927 | **OK claim** — **CORRECTED: spelling** "Lemaitre" (no circumflex) at 22:38, 23:112, and `laws/112_hubble_constant.md:10` → "Lemaître" |

### 2.5 The myths, the sources, and the scholars (docs 23 §V/VII, 24 §5.5/§6/§8, sources lines)

| Name (as in ledger) | Correct spelling | Life dates | Role claimed | Year | Verdict |
|---|---|---|---|---|---|
| Möller (Egyptologist) | Georg Möller | 1876–1921 | Eye of Horus fraction-reading hypothesis | 1911 | **OK** — German ö correct as written |
| Ritter | James Ritter | — | challenged the Eye of Horus reading | 2002 | **OK** |
| Gardiner | Alan Gardiner | 1879–1963 | ankh sandal-strap hypothesis | — | **OK** |
| Fletcher | Rachel Fletcher | — | vesica "marriage" symbolism is modern | 2004 | **OK** |
| Éliphas Lévi | Alphonse Louis Constant | 1810–1875 | pentagram "evil inversion" mid-19th c. | c.1855 | **OK** |
| König | Wilhelm König | 1897–? | Baghdad "battery" interpretation | 1938 | **OK** |
| Murray | (per ledger) Margaret A. Murray? | 1863–1963 | "absent from Murray's 1904 catalogue" (Flower of Life) | 1904 | **NEEDS SOURCE** — which Murray catalogue, 1904? (Saqqara material is 1905; Egyptological catalogues vary) |
| Whish | Charles Matthew Whish | 1794–1833 | Kerala calculus | 1834 | **OK** (paper 1832; 1834 widely cited) |
| Keely | John W. Keely | 1837–1898 | free-energy fraud; *Sci. Am.* 1899 exposé | 1899 | **OK** |
| Moray | Thomas Henry Moray | 1892–1974 | dismantled devices | — | **OK** |
| Rossi | Andrea Rossi | b. 1950 | E-Cat unvalidated | — | **OK** |
| Horowitz & Puleo | Leonard Horowitz / Joseph Puleo | — | solfeggio/528 "ancient" frequencies | 1999 | **OK** — *Healing Codes for the Biological Apocalypse* 1999 |
| Bernal | Martin Bernal | 1937–2013 | "Egypt colonized Greece" strongest claims REJECTED | — | **OK** |
| Lazaridis (genetics) | Iosif Lazaridis | b. 1984 | no Levantine/African influence in Minoans/Mycenaeans | 2017 | **OK** — *Nature* 2017; **disambiguate from Mike Lazaridis** |
| Reich (David) | David Reich | b. 1974 | Narasimhan/Reich 2019 | 2019 | **OK** |
| Narasimhan | Vagheesh Narasimhan | — | South/Central Asia formation | 2019 | **OK** |
| Haak | Wolfgang Haak | — | steppe migration paper | 2015 | **OK** |
| Wang | Jessica Wang | — | *American Science in an Age of Anxiety* | 1999 | **OK** |
| Kuhn | Thomas Kuhn | 1922–1996 | *The Structure of Scientific Revolutions* | 1962 | **OK** |
| Merton | Robert K. Merton | 1910–2003 | "Matthew Effect" / sociology of science | 1968 | **OK** |
| Bird & Sherwin | Kai Bird / Martin J. Sherwin | 1951– / 1937–2021 | *American Prometheus* (Oppenheimer) | 2005 | **OK** |
| Peat | F. David Peat | 1938–2017 | *Infinite Potential* (Bohm) | 1997 | **OK** |
| Joseph | George Gheverghese Joseph | — | *The Crest of the Peacock* | 1991 | **OK** |
| Pingree | David Pingree | 1933–2005 | history of exact sciences | 1992 | **OK** |
| El-Abbadi | Mostafa El-Abbadi | 1928–2017 | Library of Alexandria scholarship | — | **OK** |
| Canfora | Luciano Canfora | b. 1942 | Library of Alexandria scholarship | — | **OK** |
| MacLeod | Roy MacLeod | 1938–2023 | Library of Alexandria scholarship | — | **OK** |
| Gutas | Dimitri Gutas | b. 1945 | House of Wisdom / Greek-Arabic translation | — | **OK** |
| Scholem | Gershom Scholem | 1897–1982 | Star of David history | — | **OK** |
| Seifer | Marc Seifer | b. 1948 | Tesla biography | 1996 | **OK** |
| Carlson | W. Bernard Carlson | — | Tesla biography | 2013 | **OK** |
| O'Neill | John J. O'Neill | 1889–1953 | Tesla biography; "3-obsession" | 1944 | **OK** |
| Trump | John G. Trump | 1907–1985 | evaluated Tesla's seized papers | 1943 | **OK** |
| Edison | Thomas Edison | 1847–1931 | DC in the AC/DC war | — | **OK** |
| Tesla | Nikola Tesla | 1856–1943 | 1892 London IEE "static or kinetic"; DToG 1937; 4 of 5 famous quotes fake | 1892/1937 | **OK** |
| Wegener | Alfred Wegener | 1880–1930 | continental drift; establishment was wrong | 1910s–20s | **OK** |
| Goethe | J. W. von Goethe | 1749–1832 | color science | 1810 | **OK** |
| Helmholtz | Hermann von Helmholtz | 1821–1894 | praised Goethe's observations, rejected theory | — | **OK** |
| Tyndall | John Tyndall | 1820–1893 | "It is the power of interpretation that he lacks" | — | **OK** |
| Hering | Ewald Hering | 1834–1918 | opponent-process color | — | **OK** |
| Judd | Deane B. Judd | 1900–1972 | Goethe's theory dismissed too quickly | 1970 | **OK** |
| Owen | Richard Owen | 1804–1892 | serial homology | 1843 | **OK** |
| Schelling | F. W. J. Schelling | 1775–1854 | *Von der Weltseele* | 1798 | **OK** |
| Ørsted | Hans Christian Ørsted | 1777–1851 | electromagnetism deliberately sought | 1820 | **OK** |
| Faraday | Michael Faraday | 1791–1867 | dynamic field | — | **OK** |
| Comte | Auguste Comte | 1798–1857 | positivism | c.1840 | **OK** |
| Liebig | Justus von Liebig | 1803–1873 | Naturphilosophie = "the Black Death" | — | **OK** |
| Whitehead | Alfred North Whitehead | 1861–1947 | process philosophy | 1925/29 | **OK** |
| Bergson | Henri Bergson | 1859–1941 | *Creative Evolution* | 1907 | **OK** |
| Oppenheimer (J.R.) | J. Robert Oppenheimer | 1904–1967 | 1954 hearing; decision nullified 2022 | 1954/2022 | **OK** |
| Teller | Edward Teller | 1908–2003 | émigré establishment | — | **OK** |
| Szilard | Leó Szilárd | 1898–1964 | émigré establishment | — | **OK** |
| Fermi | Enrico Fermi | 1901–1954 | APS president | 1953 | **OK** |
| Bethe | Hans Bethe | 1906–2005 | APS president | 1954 | **OK** |
| Uhlenbeck | George Uhlenbeck | 1900–1988 | APS president | 1959 | **OK** |
| Weisskopf | Victor Weisskopf | 1908–2002 | APS president | 1960 | **OK** |
| Sacrobosco | Johannes de Sacrobosco | c.1195–1256 | *machina mundi* | 13th c. | **OK** |
| Leibniz | Gottfried Wilhelm Leibniz | 1646–1716 | Leibniz–Clarke clock | 1715–16 | **OK** |
| Clarke | Samuel Clarke | 1675–1729 | Leibniz–Clarke clock | 1715–16 | **OK** |
| Maupertuis | Pierre Louis Maupertuis | 1698–1759 | determinism precursor | 1756 | **OK** |
| d'Holbach | Paul-Henri Thiry d'Holbach | 1723–1789 | *Système de la nature* | 1770 | **OK** |
| Boscovich | Ruđer Bošković (Roger Boscovich) | 1711–1787 | determinism precursor | 1758 | **OK** — note the modern Croatian spelling "Bošković" |
| Reichenbach | Hans Reichenbach | 1891–1953 | called Laplace's demon the "Superman" | 1951 | **OK** |
| Arago | François Arago | 1786–1853 | source of the Laplace anecdote (via Faye) | — | **OK** |
| Antommarchi | Francesco Antommarchi | 1780–1838 | earliest version of the Laplace quote | 1825 | **OK** |
| Faye | Hervé Faye | 1814–1902 | reconstructed "God's intervention" reading | 1884 | **OK** |
| Herschel | *(which Herschel?)* | — | "Herschel's 1802 diary is silent" | 1802 | **NEEDS SOURCE** — name the Herschel (W. or J. Herschel) and the diary |
| Christensen | Thomas S. Christensen? | — | cited for A-440 history | 1995 | **NEEDS SOURCE** — which Christensen 1995? (candidate: the pitch-standard history) |
| Bashar | Bashar (channeled entity) | — | actual source of "everything is energy" | — | **OK** — correctly labeled non-person |
| Odlyzko | Andrew Odlyzko | b. 1949 | Riemann zeros computation | — | **OK** |
| Broadbent | Simon Broadbent | 1931–2020 | ley-line statistics | 1980 | **OK** |
| Pallett | Pallett & Link | — | golden-ratio faces study | 2010 | **OK** |
| Liu & Sumpter | David Liu / David Sumpter | — | plastic number vs φ | 2018 | **OK** |
| Ayotte | Christopher David Ayotte | — | corpus author / Licensor | 2026 | **OK** — consistent across all four documents |

---

## 3 · KEY-PEOPLE CHECKLIST VERDICTS (from the C1 mandate, incl. absentees)

Verified in table above: Rockefeller Sr./Jr., Gates (F.T.), Weaver, Flexner, Carnegie, Ford, McCloy, Shapley, Reich, Velikovsky, Condon, F. Oppenheimer, Weinberg, Peters, Bohm, de Vaux, Knorozov, Thompson, Budge, Breasted, Albright, Cyrus Thomas, Renan, Zilsel, Noether, Planck, Eddington, Aspect, Clauser, Zeilinger, Wegener, Bernal, Iosif Lazaridis, David Reich, Fulbright, Tesla, Boltzmann, Prigogine, Penrose, Koch, Chalmers, Goff, Strawson, Rovelli, Smolin, Barbour, Ursachi, Coldea, Livio, Markowsky, Seife, Nothaft, Ayotte.

**Checked and ABSENT from the ledger docs (no correction needed in 32_PHI_PHYSICS; noted for the wider corpus / ancient-research register):**

| Key name | Ledger status | Note |
|---|---|---|
| Michael Josselson | ABSENT | CCF secretary; optional name under the CCF row |
| J.T. Milik / Frank Moore Cross / Patrick Skehan / John Strugnell | ABSENT | DSS editors; only de Vaux is named |
| Georges Semaan | ABSENT | no appearance anywhere in the corpus |
| James Hutton (earth mysteries) | ABSENT | |
| John Michell | ABSENT | |
| R.A. Schwaller de Lubicz | ABSENT | |
| John Anthony West | ABSENT | |
| Robert Schoch | ABSENT | |
| Keith Critchlow | ABSENT | |
| Buckminster Fuller | ABSENT | |
| Arthur M. Young | ABSENT | |
| Robert Lawlor | ABSENT | |
| Alfred Watkins | ABSENT | |
| Sabetai Unguru | ABSENT | |
| Giordano Bruno | ABSENT | only "Bruno" in physics-law names (Pontecorvo, Zumino, Zimm, Christoffel) |
| Fatima al-Fihri | ABSENT | "al-Qarawiyyin" named at 23:274, founder not |
| Ahmed Baba | ABSENT | Timbuktu manuscripts named, institute founder not |
| Klaus Schmidt | ABSENT | "Göbekli's architecture" named, discoverer not |
| Dan Shechtman | ABSENT | only "quasicrystals/Penrose tilings" at 22:66 |
| Barry Marshall / Robin Warren | ABSENT | only "H. pylori" at 24:246 |
| Gene Shoemaker | ABSENT | only "craters" at 24:246 |
| Neil Bartlett | ABSENT | only "noble gases" at 24:246 |
| Martin Bernal | present — OK | in ledger (23:244) |
| Mary Lefkowitz | ABSENT | Bernal's critic never named |
| Max Müller | ABSENT | |
| William Jones | ABSENT | |
| Thomas Young (Egyptologist) | ABSENT | "Thomas Young" in the corpus is the physicist (double-slit, 1801; trichromacy) |
| Henry/Edsel Ford | present — OK | not individually named (suggest "Henry & Edsel Ford") |

---

## 4 · CROSS-DOCUMENT INCONSISTENT-SPELLING FLAGS

| Name | Documents that disagree | Correct form | Action |
|---|---|---|---|
| **Knorozov** | `23:133, 183, 206` write "Knorosov"; `24:29, 221` and `00:202` write "Knorozov" | **Knorozov** (Yuri Valentinovich Knorozov; the "s" form occurs only in an Antiquity obituary) | Fix doc 23 |
| **Lemaître** | `22:38`, `23:112`, `laws/112_hubble_constant.md:10` write "Lemaitre"; `laws/1124`, `laws/1184`, `laws/1227`, `laws/1234`, `expansion_log/agent5` write "Lemaître" | **Lemaître** | Fix 22/23 + law 112 |
| **J. Eric Thompson** | `24:221` "J. Eric Thompson"; `23:133` "Thompson" | **J. Eric S. Thompson** (S. = Sidney) | Add middle initial at 24:221 (and ideally at first use in 23:133) |
| **Möller (Egyptologist) vs Møller (physicist)** | `23:144, 280`, `24:237` use "Möller" (correct for Georg Möller, German ö); `laws/1366`, `laws/1527`, `sim/`, `validation/`, `expansion_log` use ASCII "Moller" for Christian Møller (Danish ø) | **Georg Möller** (ö); **Christian Møller** (ø) | Documentation note only — diacritics are correct in the history docs; physics law files use ASCII. Do not "fix" the ø to ö in either place. |
| **Gates** | `23:89` "Gates (Core)" = Bill Gates; `24:186/367` archive id `countryschooloft00gates` = Frederick Taylor Gates | two different people | Add given names |
| **Lazaridis** | `22:139`, `23:98` = Mike (Perimeter); `23:244`, `24:367` "Lazaridis (2017)" = Iosif (ancient DNA) | two different people | Add given names |

---

## 5 · THE FIX LIST (exact — audit only, nothing edited)

### Corrections (3 names, 7 lines)
1. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:133`** — "Knorosov's phonetic key" → **"Knorozov's phonetic key"**.
2. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:183`** — "Knorosov's Mayan key" and "Knorosov" (Who cell) → **"Knorozov's Mayan key" / "Knorozov"** (2 occurrences).
3. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:206`** — "Knorosov's Mayan key resisted" → **"Knorozov's Mayan key resisted"**.
4. **`22_THE_HISTORICAL_INVESTIGATION.md:38`** — "called Lemaitre's work" → **"called Lemaître's work"**.
5. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:112`** — "called Lemaitre 'abominable'" → **"called Lemaître 'abominable'"**.
6. **`laws/112_hubble_constant.md:10`** — "Lemaitre (1927)" → **"Lemaître (1927)"** (match the other 5 law files).
7. **`24_THE_GEOMIC_LEDGER.md:221`** — "J. Eric Thompson" → **"J. Eric S. Thompson"** (and at first mention in `23:133`).

### Disambiguation (recommended, optional)
8. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:89`** — "Gates (Core)" → "**Bill** Gates / Gates Foundation (Core)" to separate from Frederick Taylor Gates.
9. **`24_THE_GEOMIC_LEDGER.md:186/188/367`** — name **Frederick Taylor Gates** as author of GEB Occasional Papers No. 1 (the "molding hand" document, 1913) — the ledger's money table cites the quote but never names its author.
10. **`22_THE_HISTORICAL_INVESTIGATION.md:139` / `23_THE_SYSTEM_OF_THE_FABRICATION.md:98`** — "Lazaridis" → "**Mike** Lazaridis" (Perimeter); **`23:244` / `24:367`** → "**Iosif** Lazaridis" (2017 genetics).
11. **`23_THE_SYSTEM_OF_THE_FABRICATION.md:47` / `24_THE_GEOMIC_LEDGER.md:181`** — "Harriman" → "**Mary W. Harriman** (Mrs. E. H. Harriman)".

### Needs a named source / year confirmation (14 items)
12. **Ursachi 2026** (`22:60`, `23:125`, `00:211`) — 2026-dated publication; **re-verify PMID 41859481 live on PubMed at release** (cannot be confirmed from this environment).
13. **Velikovsky/Shapley boycott** (`24:215`, `23:203`) — EVIDENCE cell is bare "[VERIFIED]"; add a named account (matches A7 #8).
14. **Knorozov** (`24:221`) — "epigraphy histories"; name Coe, *Breaking the Maya Code* (1992) (matches A7 #11; web-confirmed this is the standard source).
15. **Noether** (`24:229`) — add citation for the Einstein 1935 tribute (NYT, May 1935) and "never a full professor" (matches A7 #15).
16. **Renan 1883** (`24:227`) — confirm whether "le miracle grec" is the 1883 *Souvenirs* or the 1890 *L'Avenir de la science*.
17. **Kline 1962** (`23:136`) — confirm *Mathematics: A Cultural Approach* (1962) vs *Mathematics in Western Culture* (1953) for "scrawling of children."
18. **Watkiss-Lloyd 1863** (`23:153`) — name the source for the Parthenon 4:9 attribution; could not verify online.
19. **Murtinho 2015** (`22:112`, `23:152`, `24:243`) — keep, but flag as not independently re-verified in this pass.
20. **Murray 1904** (`23:147`) — name the Murray catalogue referenced for the Flower of Life.
21. **Kozol "cognitive decapitation"** (`23:89`) — name the Kozol text using the phrase.
22. **Herschel 1802** (`24:267`) — name which Herschel and which diary.
23. **Christensen 1995** (`22:191`, `23:280`, `24:367` sources lines) — identify the Christensen (A-440 / pitch history?) work.
24. **Carnegie Corporation $135M (1911)** (`23:42`, `24:190`) — verify against the commonly cited $125M.
25. **Carnarvon £500,000 (1922)** (`23:55`, `00:181`) — verify the nominal figure.

### Not corrections — cross-checks that passed
26. Rockefeller Sr. vs Jr. separation — **correct as written** (Sr.: UChicago/GEB/RF; Jr.: Oriental Institute/Met).
27. APS presidents Fermi 1953 / Bethe 1954 / Wigner 1956 / Uhlenbeck 1959 / Weisskopf 1960 — **all five verified correct**.
28. Knorozov claim (1952 phonetic key; Thompson resistance; vindicated post-1975) — **web-confirmed accurate**.
29. Zilsel 1942 (*Phil. Rev.* 51:245) — **citation verified correct**.
30. Coldea 2010 (*Science* 327:177, E8/golden-ratio masses, CoNb₂O₆) — **verified correct**; the task's "which Coldea did E8" = **Radu Coldea** (Oxford).
31. Møller/Möller distinction — **both correct in their own contexts** (German ö for the Egyptologist, Danish ø/ASCII for the physicist); do not "harmonize."
32. "Nothaft" — surname correct; full name is **C. Philipp E. Nothaft** (the task's "David Nothaft" is a false lead).

---

## 6 · BOTTOM LINE

148 distinct names checked. The ledger's people-register is release-grade: 133 verified correct including every load-bearing suppression, money, and science figure. Three real spelling defects to fix (Knorozov ×3 lines in doc 23, Lemaître ×3 lines, J. Eric S. Thompson ×1 line) plus 14 items needing a named source or year confirmation, none of which changes a person's identity or role. 26 checklist names are simply absent from the ledger docs — most live in the `01_ANCIENT_RESEARCH` register and should be audited there, not here. The A7 prior audit's source fixes remain the companion list (Velikovsky, Reich quoter, DSS record, Knorozov/Coe, Noether, Nazi-440/Reich-death).

*No files were edited — audit only.*
