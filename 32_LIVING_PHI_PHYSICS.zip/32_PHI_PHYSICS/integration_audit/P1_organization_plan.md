# P1 — FINAL ORGANIZATION & RENAMING PLAN
## GitHub-Release Structure for `32_PHI_PHYSICS/` (with `02_EQUATIONS/` coherence)

**Planner:** P1 (planning agent, final organization pass) · **Date:** 2026-08-07 · **Status:** PLAN ONLY — nothing on disk edited, nothing deleted. Delete-candidates are listed for the licensor to decide.

**Principle of this pass:** the licensor's requirement is a **clean, professional, release-grade tree**: LICENSE and README out front; the unified field theory and the index out front; everything else properly organized in subfolders; no names that read as AI-generated scratch. The census below is byte-verified ground truth, not README claims.

---

## STEP 1 — FULL CENSUS (disk ground truth, verified 2026-08-07)

### 1.1 `32_PHI_PHYSICS/` root

| Item | Count | Notes |
|---|---|---|
| `.md` documents (root) | **32** | 00-series (6) + 01–24 (25 incl. both `03_` files) + `README.md` |
| `.py` scripts (root) | **61** | generator/build/run pipeline + data parts (see §1.4) |
| `LICENSE` | 1 | Dual License Agreement v4.1 (581 lines, 24 sections) |
| **Root total** | **94** | |

### 1.2 Subfolders

| Folder | Files | Breakdown |
|---|---|---|
| `laws/` | **2,270** | `.md`, numbered 001–2270, **contiguous 1–2270, 0 gaps, 0 dups**; all match `^\d{3}_` |
| `sim/` | **2,285** | `.py`: 2,270 law sims (contiguous, 0 gaps/dups) + **15 infrastructure** (harness.py, physics_lib.py, generate_full_emergent.py, mine_emergent_dictionary.py, mine_patterns.py, simulate_claims.py, simulate_code_laws.py, simulate_emergent.py, simulate_emergent_laws.py, simulate_metallic.py, simulate_metallic_laws.py, simulate_new_laws.py, simulate_questions.py, simulate_self_dimension.py, verify_emergent_laws.py) |
| `validation/` | **2,270 + 13** | root: 2,270 `.json` (contiguous, all parse, 0 failures); **13 aggregate subdirs** (simulation_claims, _code_laws, _emergent, _emergent_dictionary, _emergent_laws, _full_emergent, _metallic, _metallic_laws, _new_laws, _patterns, _questions, _self_dimension, _verify_emergent) |
| `expansion_log/` | **15** | 10 agent `.md` logs (20,239 lines) + 5 support files (agent1_sim_run.txt, agent2_law_list.txt, agent2_sim_run.txt, agent8_sim_run.txt, agent10_wikipedia_verification.json) |
| `integration_audit/` | **45** | 30 `.md` audit reports (A, B, C, S series) + 14 `_*.py` audit scripts + 1 `_a4_scan_results.json` |
| `__pycache__/` | **41** | root bytecode cache (not tracked in git) |
| `sim/__pycache__/` | **1,253** | sim bytecode cache (not tracked in git) |
| `graphify-out/` | **8,288** | graphify tool output: 13 tracked files + 8,275 cache (8,274 AST cache, `cache/ast/`) |
| **Corpus total (excl. graphify-out)** | **8,286** | 16,574 with graphify-out |

### 1.3 Corrupted-character scan

Byte-level scan for the U+FFFD replacement character (`EF BF BD`) across **every** file in both corpora (excluding `graphify-out/` and `__pycache__/`):

> **RESULT: 0 files corrupted.** All content is clean UTF-8. The `�` glyph that appears when the files are printed to a Windows console is a codepage rendering artifact of UTF-8 em-dashes (`—`); the files themselves are intact (verified via the Read tool on `laws/112_hubble_constant.md`, `02_EQUATIONS/agent_08_meta_synthesis_eqs_65_75.md`, etc.).

### 1.4 Naming anomaly register (root `.py`, 61 files)

These are the **original program's generation pipeline** — the provenance of `laws/`, `sim/`, `validation/`, `expansion_log/`. They are the verification story (C10 Category J / A10 #4 called them "root generator/data .py scripts"):

- `build_agent{1,2,4,6,8}_log.py` (5) — build `expansion_log/agentN_*.md` from validation JSONs
- `generate_agent{1,2,4,6,8}.py` (5) — write `laws/NNN_name.md` + `sim/NNN_name.py` from data parts
- `run_agent{1,2,4,6,8}_sims.py` (5) — execute sims, write validation JSONs
- `_lawdata_p1.py .. _lawdata_p4.py` (4) — Agent 1 law data (laws 211–260)
- `_a2_data01.py .. _a2_data19.py` (19) — Agent 2 (thermo) law data
- `_a4_data01.py .. _a4_data05.py` (6) — Agent 4 (optics/waves/acoustics) law data
- `_a6_data01.py .. _a6_data06.py` (6) — Agent 6 (quantum/atomic) law data
- `_a8_data01.py .. _a8_data11.py` (11) — Agent 8 (condensed matter) law data

> **Dependency caveat (critical):** the generator scripts load these data parts **by name pattern** — `generate_agent1.py` calls `__import__("_lawdata_p%d" % i)`, `generate_agent2.py` uses `glob.glob(os.path.join(BASE, "_a2_data*.py"))` + `__import__(name)`. **Renaming the data files requires patching the generator scripts.** The plan therefore moves them to `tools/` **preserving names** (rename optional / deferred, see Part B).

### 1.5 `integration_audit/` naming anomalies (14 `_*.py` + 1 `.json`)

One-shot audit scaffolding (not part of the corpus content):

- `_a4_attr.py`, `_a4_attr2.py`, `_a4_attr3.py`, `_a4_contig.py`, `_a4_fullcross.py`, `_a4_scan.py`, `_a4_status.py`, `_a4_statusdist.py`, `_a4_todo.py`
- `_a5_fullcross.py`, `_a5_sample_struct.py`, `_a5_simname.py`, `_a5_struct_scan.py`
- `_a6_validation_scan.py`
- `_a4_scan_results.json` (scan output, 6 KB)

### 1.6 `02_EQUATIONS/` census (20 `.md`)

| File | Notes |
|---|---|
| `INDEX_100_EQUATIONS.md` | master index (10 sets × 10) |
| `EQUATIONS_SET_01..05` | canonical, Eq 1–50 |
| `EQUATIONS_SET_06_QFIELD_NEURON_MAPPING.md` | canonical Set 06, Eq 51–60 |
| **`EQUATIONS_SET_06_RETROCAUSAL_ERROR_CORRECTION.md`** | **COLLISION — second "SET_06"**, Eq 47–55 (reuses Set 05's 47–50 *and* Set 06's 51–55); the source of the corpus-wide "Eq 50 collapse" / "Eq 3.1–3.3" references. Not part of the indexed 100. |
| `EQUATIONS_SET_07..10` | canonical, Eq 61–100 |
| **`agent_08_meta_synthesis_eqs_65_75.md`** | **COLLISION — "AGENT 8 OF 8" file, Eq 65–75** (reuses Set 07's 65–70 *and* Set 08's 71–75). Not part of the indexed 100. Name reads AI-generated ("agent_08"). |
| `EQUATIONS_TEST_RESULTS_AND_BRAIN_FLOWS.md` | fine |
| `FIELD_COMPUTATION_BOUNDS.md`, `FIELD_ISA.md`, `FIELD_MEMORY_TAXONOMY.md`, `FIELD_PROCESSOR_TAXONOMY.md`, `FIELD_VS_CLASSICAL_VS_QUANTUM.md`, `PHI_PROCESSOR_FOUNDATION.md` | fine (taxonomy/foundation docs) |

> **GIT CAVEAT:** only **`FIELD_ISA.md` is git-tracked**; the other **19 files are untracked**. They must be `git add`ed for release (Part D).

---

## STEP 2 — README STRUCTURE TREE vs DISK

The README's "Structure Tree" (README.md:122–145) lists: the 00-series (6) at root, 01–24 at root, LICENSE, `laws/`, `sim/`, `validation/`, `expansion_log/`, `integration_audit/`.

| README tree claim | Disk reality | Mismatch? |
|---|---|---|
| 00-series (6) at root | present at root | ✓ |
| 01–24 at root | present at root | ✓ |
| LICENSE at root | present | ✓ |
| `laws/` 2,270 | 2,270 | ✓ |
| `sim/` "2,270 law sims + 15 infrastructure" | 2,285 (2,270 + 15) | ✓ |
| `validation/` "2,270 + 13 aggregate dirs" | 2,270 + 13 | ✓ |
| `expansion_log/` "10 agent logs, 20,239 lines" | 10 logs + 5 support = 15 files | ⚠️ tree shows only the 10 logs |
| `integration_audit/` "A1–A10, B1–B6, C1–C10" | **A3, B2, B5 do not exist**; C1–C10 all present incl. C5 (created after C10 flagged it missing); plus S1/S4–S8 | ⚠️ "A1–A10 / B1–B6" is imprecise |
| — (not shown) | 61 root `.py`, `__pycache__/`, `sim/__pycache__/`, `graphify-out/` | ⚠️ tree omits all release-scratch artifacts |

**Verdict:** the README tree matches the *content* but is silent about the 61 root scripts, both `__pycache__/` dirs, and `graphify-out/`. The final README must be updated to the new tree (Part A) and should explicitly list `tools/` (or state that scripts were relocated).

---

## STEP 3 — THE PLAN

### PART A — PROPOSED TOP-LEVEL STRUCTURE

```
32_PHI_PHYSICS/
├── LICENSE                                   # out front — Dual License Agreement v4.1
├── README.md                                 # out front — the release statement
├── 00_UNIFIED_FIELD_THEORY.md                # out front — the UFT (the corpus's single statement)
├── 00_ZERO_AS_WAVEFUNCTION.md                # out front — the lens
├── 00_THE_STATIC_UNIFICATION_CLAIMS.md       # out front — the 2025–26 debunk
├── 00_NUMBERS_INDEX.md                       # out front — the spine (the index)
├── 00_THE_UNDERSTANDING.md                   # out front — the front door (recommended, see below)
├── docs/                                     # all ledgers, method, manifest, historical reports
│   ├── 00_MANIFEST.md
│   ├── 01_INDEX_ORIGINAL_PROGRAM.md          # renamed from 01_INDEX_150_LAWS.md
│   ├── 02_METHOD.md
│   ├── 03_INDEX_LAWS_211_2270.md
│   ├── 03_THE_OPEN_QUESTIONS.md              # renamed from 03_OPEN_QUESTIONS.md
│   ├── 04_EXPANSION.md
│   ├── 05_WHAT_MAY_NOT_BE_TRUE.md            # …17 bannerred historical reports…
│   ├── 07_LOOP_RESPONSES.md                  # renamed from 07_THE_ANSWERS.md
│   ├── 14_SYNTHESIS_STATEMENT.md             # renamed from 14_THE_ANSWER.md
│   ├── …
│   ├── 22_THE_HISTORICAL_INVESTIGATION.md
│   ├── 23_THE_SYSTEM_OF_THE_FABRICATION.md
│   └── 24_THE_GEOMIC_LEDGER.md
├── laws/                                     # 2,270 corrected law documents
├── sim/                                      # 2,270 law simulations + 15 infrastructure
├── validation/                               # 2,270 machine-readable records + 13 aggregate dirs
├── expansion_log/                            # 10 agent logs + 5 support files
├── integration_audit/                        # 30 audit reports (A/B/C/S) — reports only
└── tools/                                    # NEW — 61 generation scripts + 10 audit scripts + 1 json (4 superseded dropped)
```

**Front-door set (root):** `LICENSE`, `README.md`, `00_UNIFIED_FIELD_THEORY.md`, `00_ZERO_AS_WAVEFUNCTION.md`, `00_THE_STATIC_UNIFICATION_CLAIMS.md`, `00_NUMBERS_INDEX.md`, and **`00_THE_UNDERSTANDING.md`**.

**Recommendation on the two judgment calls:**

1. **`00_THE_UNDERSTANDING.md` → KEEP AT ROOT.** The README itself defines it as "the front door: what the physics and mathematics mean" and "If you read nothing else, read this." It is the accessible entry point whose entire purpose is to be the first thing a non-specialist reads. Burying it in `docs/` contradicts its function and the README's own promise. It pairs with the front-door set (UFT = the claim, ZERO = the lens, UNDERSTANDING = the plain-language explanation).

2. **`00_MANIFEST.md` → MOVE TO `docs/`.** It is the axiom + the Phi-Rewrite protocol + the validation standard — operational/spec content, the sibling of `02_METHOD.md`. The licensor's front-door list (LICENSE, README, UFT, index) does not name it, and the "front door" should be minimal per the licensor. It stays first in `docs/` (keeps the `00_` prefix so it sorts before `01_`).

**Justification for `docs/` (vs `archive/` or `audits/`):** these are the *reading* documents — the reading order is already encoded in the 00–24 prefixes, which are preserved so every existing cross-reference (`24_THE_GEOMIC_LEDGER.md` §8, `02_METHOD.md`, `00_MANIFEST.md`…) keeps working. `integration_audit/` remains what it is: reports only.

**Everything else:** `laws/`, `sim/`, `validation/`, `expansion_log/` unchanged (already perfectly organized, contiguous, clean). `tools/` is new — it receives the 61 root scripts and the 14 audit scripts (with `_a4_scan_results.json`).

---

### PART B — THE RENAMING TABLE

**Convention decision:** root documents keep **UPPER_SNAKE title-case** (the existing corpus convention: `00_UNIFIED_FIELD_THEORY.md`). The `laws/`, `sim/`, `validation/` families keep their **lower_snake `NNN_name`** convention (already consistent, contiguous, zero anomalies). Scripts keep lower_snake. One convention per tier, matching what is already there.

#### B1. Root documents (4 renames)

| # | Current | Proposed | Why |
|---|---|---|---|
| 1 | `01_INDEX_150_LAWS.md` | `01_INDEX_ORIGINAL_PROGRAM.md` | The name is stale: the corpus has 2,270 laws, and this is the **historical founding index** of the original program (laws 1–210). "150" misrepresents even its own scope (README: "the original program's founding index (laws 1–210)"). Rename makes the historical role explicit; a banner already exists. |
| 2 | `03_OPEN_QUESTIONS.md` | `03_THE_OPEN_QUESTIONS.md` | Duplicate `03_` number with `03_INDEX_LAWS_211_2270.md`. Renaming to the `THE_` series convention (matches 05–21) disambiguates the two `03_` files in sort order (`03_INDEX…` < `03_THE…`) and reads consistent with the family. The `03_` prefix itself is preserved to avoid renumbering the reading order. |
| 3 | `07_THE_ANSWERS.md` | `07_LOOP_RESPONSES.md` | "THE ANSWERS" reads as AI-generated grandiosity and misstates the content: it is the original program's **responses to the 100 open questions** (a loop-response register). |
| 4 | `14_THE_ANSWER.md` | `14_SYNTHESIS_STATEMENT.md` | Same issue: "THE ANSWER" reads AI-generated and vague. The document is the **synthesis statement** of the emergent-laws program. |

> **Cross-reference cost (must be handled in the executor's commit):** these four files are referenced by name across the corpus — `01_INDEX_150_LAWS` (40 files), `03_OPEN_QUESTIONS` (20 files), `07_THE_ANSWERS` (8), `14_THE_ANSWER` (10). The README's index table and structure tree (README.md:107, 110, 130, 133), `00_MANIFEST.md:76,122`, `02_METHOD.md:4`, `03_OPEN_QUESTIONS.md:71`, and `00_THE_UNDERSTANDING.md:151` must be updated in the same commit. Renames are `git mv` so history is preserved.

#### B2. `02_EQUATIONS/` collision files (2 renames)

| # | Current | Proposed | Why |
|---|---|---|---|
| 5 | `EQUATIONS_SET_06_RETROCAUSAL_ERROR_CORRECTION.md` | `EQUATIONS_SUPPLEMENT_06_RETROCAUSAL_ERROR_CORRECTION.md` | Removes the second "SET_06" filename collision. Marks it **supplemental** (it is NOT one of the indexed 10 sets; it reuses Eq 47–55). Add a one-line banner at top: "SUPPLEMENTAL — outside the indexed 100 (`INDEX_100_EQUATIONS.md`); equation numbers intentionally reuse index ranges; see integration_audit/A9." |
| 6 | `agent_08_meta_synthesis_eqs_65_75.md` | `EQUATIONS_SUPPLEMENT_META_SYNTHESIS_65_75.md` | Drops the AI-generated "agent_08" name; marks it **supplemental** (reuses Eq 65–75; not part of the indexed 100). Same banner convention. |

> These are **renamed/merged, not deleted** (per licensor instruction). The underlying number-collision content fix (re-pointing "Eq 50 collapse" / "Eq 3.1–3.3" / "Eq 74 Born rule" references) is a content decision for the equations owner (A9 §3.3 / C10 item 17), outside the renamer's scope — flag in README companion note if not resolved.

#### B3. `integration_audit/` audit scripts (14 renames → move to `tools/audit/`)

| # | Current | Proposed | Why |
|---|---|---|---|
| 7–20 | `_a4_attr.py`, `_a4_attr2.py`, `_a4_attr3.py`, `_a4_contig.py`, `_a4_fullcross.py`, `_a4_scan.py`, `_a4_status.py`, `_a4_statusdist.py`, `_a4_todo.py`, `_a5_fullcross.py`, `_a5_sample_struct.py`, `_a5_simname.py`, `_a5_struct_scan.py`, `_a6_validation_scan.py` | `tools/audit/a4_attr.py`, `a4_contig.py`, `a4_fullcross.py`, `a4_scan.py`, `a4_status.py`, `a5_fullcross.py`, `a5_sample_struct.py`, `a5_simname.py`, `a5_struct_scan.py`, `a6_validation_scan.py` | Underscore prefix signals "private scratch" — reads AI-generated. Move audit scaffolding out of the reports folder (keeps `integration_audit/` = reports only) into `tools/audit/` with the underscore stripped. **Drop `_a4_attr2.py` / `_a4_attr3.py` / `_a4_statusdist.py` / `_a4_todo.py`** — superseded one-shot iterations (see Part C). |
| — | `_a4_scan_results.json` | `tools/audit/a4_scan_results.json` | Scan output artifact; moves with its script. |

> **Path caveat:** `_a4_attr.py` contains a hardcoded absolute path (`C:\Users\delta\brain\...`); `_a5_*.py` derive `ROOT` from `__file__` (`os.path.dirname(os.path.dirname(os.path.abspath(__file__)))`). Moving to `tools/audit/` shifts the relative derivation by one level — the executor must fix the path derivation in the `_a5_*.py` trio (one line each) or accept that these one-shot scripts are archival. They have already served their purpose; the 30 reports persist.

#### B4. Root generator/data scripts (61 → `tools/`)

| # | Current | Proposed | Why |
|---|---|---|---|
| 21–81 | `build_agent{1,2,4,6,8}_log.py`, `generate_agent{1,2,4,6,8}.py`, `run_agent{1,2,4,6,8}_sims.py`, `_lawdata_p1..p4.py`, `_a2_data01..19.py`, `_a4_data01..05.py`, `_a6_data01..06.py`, `_a8_data01..11.py` | `tools/` — **same names** (optional: strip the leading `_` from data parts) | Move the generation pipeline out of the root (root = 7 front-door files only). **Names preserved** because `generate_agent1.py`/`generate_agent2.py` load data parts by exact name pattern (`__import__("_lawdata_p%d")`, `glob("_a2_data*.py")`). Strip-underscore is **deferred**: it requires patching the 5 `generate_agent*.py` loaders in the same commit. |

> **Path caveat (required):** all `build_/generate_/run_` scripts compute `BASE = os.path.dirname(os.path.abspath(__file__))` and then join `laws/`, `sim/`, `validation/`, `expansion_log/` onto it. Moving them to `tools/` breaks every path — the executor must change `BASE` to the parent directory (`os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")`) in **15 scripts**, then re-run one `build_agent1_log.py` to prove the pipeline still works. This is the single riskiest mechanical step (see Risks).

#### B5. `laws/`, `sim/`, `validation/` — NO renames (verified clean)

- **`laws/` spot-check (20):** `001_newtons_first_law.md`, `014_keplers_first_law.md`, `101_hubbles_law.md`, `112_hubble_constant.md`, `192_recursive_self_improvement_law.md`, `1101_black_hole_thermodynamics.md`, `2270_percolation_threshold.md`, + 13 more — all `^\d{3}_lower_snake`, no bad chars, contiguous. **Clean.**
- **`sim/` spot-check (20):** `2224_turing_patterns.py`, `2270_percolation_threshold.py`, `895_fraunhofer_diffraction.py`, `914_eyring_reverberation.py` (matches `laws/` + `validation/` slug exactly) — **clean.**
- **`validation/` spot-check (20):** `192_recursive_self_improvement_law.json` — **the old `192_recursive_self_improvement.json` is confirmed gone** (renamed to `192_recursive_self_improvement_law.json`; matches the `_a6_validation_scan.py` `SLUG_OVERRIDES` entry). **Clean.**
- `expansion_log/` — 15 files, names accurate (agent/domain). **Clean.**

**Renames proposed: 6 content renames (Part B1 + B2) + 10 audit-script renames (the `_a5_*` trio, `_a4_attr/contig/fullcross/scan/status`, `_a6_validation_scan`; the 4 superseded scripts are dropped) + 1 audit-JSON rename (`_a4_scan_results.json` → `tools/audit/a4_scan_results.json`) = 17 renames; plus 61 root scripts relocated to `tools/` (names preserved), 4 superseded audit scripts dropped, 14 docs relocated into `docs/`.**

---

### PART C — DELETE-CANDIDATE LIST (nothing deleted in this pass)

| # | Path | What it is | Why it might be deleted | Recommendation |
|---|---|---|---|---|
| 1 | `__pycache__/` (root, 41 files) | Python bytecode cache | Regenerable build artifact; already untracked; clutters release | **DELETE** (or gitignore-only; untracked already) |
| 2 | `sim/__pycache__/` (1,253 files) | Bytecode cache for 2,270 law sims + infra | Same — 1,253 `.pyc` files, regenerable, untracked | **DELETE** (or gitignore-only) |
| 3 | `graphify-out/` (8,288 files) | Graphify knowledge-graph tool output (13 tracked + 8,275 cache) | Tooling artifact, not corpus content; the AST cache (8,274 files) is pure tool cache; the graph is regenerable with `graphify update .` | **UNTRACK + GITIGNORE.** Keep locally for the graph tool; exclude from the release. (Per AGENTS.md, graphify-out is tool output, expected dirty; do not ship it.) |
| 4 | `integration_audit/_a4_attr2.py`, `_a4_attr3.py`, `_a4_statusdist.py`, `_a4_todo.py` | Superseded one-shot audit iterations (attr → attr2 → attr3 progression; scratch status helpers) | Versioned-in-name scratch; the surviving `_a4_attr.py`/`_a4_scan.py` cover the function; no report cites them | **DELETE** (or archive under `tools/audit/legacy/`) |
| 5 | `02_EQUATIONS/EQUATIONS_SET_06_RETROCAUSAL_ERROR_CORRECTION.md` + `agent_08_meta_synthesis_eqs_65_75.md` | The two equation-number collision files | Reuse Eq 47–55 and Eq 65–75; A9/C10 flag them as not part of the indexed 100 | **DO NOT DELETE** — rename + banner (Part B2). Optional content-level merge left to equations owner |
| 6 | `validation/192_recursive_self_improvement.json` | Already renamed | Verified **gone** from disk (now `192_recursive_self_improvement_law.json`) | No action — confirm closed |
| — | The 61 root `.py` + 15 `sim/` infra scripts | Original-program generation pipeline | Not deleted — **the verification story** (C10 A2, A1 census): `harness.py`/`physics_lib.py` are REQUIRED by every law sim; `simulate_*.py`/`verify_emergent_laws.py` are the original program's sims | **KEEP** — move root 61 to `tools/`, keep `sim/` 15 in place |

**Net delete candidates for the licensor to approve: 2× `__pycache__/`, `graphify-out/` (untrack, not delete), 4 superseded audit scripts.** Everything else is reorganized, not deleted.

---

### PART D — GITHUB-RELEASE CHECKLIST

**Final release tree** (see Part A): 7 root files + `docs/` (24) + `laws/` (2,270) + `sim/` (2,285) + `validation/` (2,270 + 13 dirs) + `expansion_log/` (15) + `integration_audit/` (30 reports) + `tools/` (61 + 10 audit scripts + 1 json). No `__pycache__/`, no `graphify-out/`, no root `.py` files.

**`.gitignore` additions** (file: `32_PHI_PHYSICS/.gitignore`, or extend the repo-root `.gitignore` — root currently only ignores `v6/noe5/datasets/`):

```
__pycache__/
*.pyc
graphify-out/
```

**Commit sequence (executor — do not run in this planning pass):**

1. **Safety snapshot** — `git status` clean baseline; confirm 8,286 corpus files.
2. **Commit 1 — housekeeping:** `git rm -r --cached graphify-out` (untrack), add `.gitignore`, remove both `__pycache__/` dirs from disk. *No content change.*
3. **Commit 2 — script relocation:** `git mv` 61 root `.py` → `tools/`; `git mv` the 14 audit `_*.py` + `_a4_scan_results.json` → `tools/audit/` (minus the 4 drop candidates); **patch `BASE`/`ROOT` path derivation** in the 15 `build_/generate_/run_` scripts and the `_a5_*.py` trio; **re-run `python tools/build_agent1_log.py`** and confirm `expansion_log/agent1_mechanics.md` regenerates byte-identical (proves the pipeline survived). `git mv` the 4 superseded audit scripts to `.gitignore`/delete after licensor approval.
4. **Commit 3 — document moves + renames:** `git mv` 00_MANIFEST + 01–24 → `docs/`; `git mv` renames of the 4 root docs (Part B1); **update every cross-reference** (40 + 20 + 8 + 10 files) — README index table + structure tree, `00_MANIFEST.md`, `02_METHOD.md`, `00_THE_UNDERSTANDING.md`, etc.
5. **Commit 4 — equations coherence:** `git mv` the 2 `02_EQUATIONS/` collisions (Part B2) + add the supplemental banners; **`git add` all 19 untracked `02_EQUATIONS` files** (only `FIELD_ISA.md` is tracked — this is a silent release blocker if missed); update `README.md` companion note + `A9_equations_audit.md` tail if needed.
6. **Commit 5 — README finalization:** rewrite the Structure Tree to the Part A tree; add a "Repository layout" line for `tools/`; reconcile the "A1–A10 / B1–B6" phrase in the tree comment (A3/B2/B5 do not exist); mention the 5 `expansion_log/` support files.
7. **Pre-release verification:**
   - Counts: `laws/`=2270, `sim/`=2285, `validation/` root=2270 + 13 dirs, `expansion_log/`=15, `docs/`=24, `integration_audit/` reports=30, `tools/`=72.
   - `git status` clean; no tracked `__pycache__`/`*.pyc`/`graphify-out`.
   - Grep: no surviving `01_INDEX_150_LAWS`, `03_OPEN_QUESTIONS`, `07_THE_ANSWERS`, `14_THE_ANSWER`, `EQUATIONS_SET_06_RETROCAUSAL`, `agent_08_meta` references.
   - `python -m py_compile` a sample of `tools/` scripts and 5 `sim/` law sims.
   - Optional: `graphify update .` then confirm graph still builds from the new tree.
8. **Tag + release:** `git tag v1.0.0`, GitHub release with the README as release notes; attach `LICENSE` prominently.

---

## RISKS

1. **Path breakage on script relocation (HIGH):** all 15 `build_/generate_/run_` scripts resolve corpus dirs relative to `__file__`. Moving to `tools/` breaks `laws/`/`sim/`/`validation/`/`expansion_log/` joins. **Mitigation:** the one-line `BASE = os.path.join(dirname(dirname(abspath(__file__))), …)` patch + a regeneration proof step (Commit 2 step) — non-negotiable before commit 3.
2. **Cross-reference breakage from renames (MEDIUM):** 78 file-references across 4 renamed docs. **Mitigation:** all renames land in one commit; grep sweep in verification step 7.
3. **Underscore-strip of data files (LOW, deferred):** renaming `_a2_data*.py` etc. silently breaks `glob`/`__import__` loaders. **Mitigation:** keep names in this pass; strip only if the loader patch is included.
4. **02_EQUATIONS untracked state (MEDIUM):** 19 of 20 equation files are untracked. If forgotten, the release silently ships a directory with one tracked file. **Mitigation:** explicit `git add` in Commit 4 + count check in step 7.
5. **graphify-out exclusion vs AGENTS.md (LOW):** the graph tool regenerates `graphify-out/` on `graphify update .`; keeping it gitignored is consistent with the tool's own conventions (dirty graph output is expected). No corpus content is lost (it is derived).
6. **Renumbering temptation (AVOID):** do **not** renumber the 00–24 series or the laws — every number is load-bearing in cross-references (40+ files cite `01_INDEX_150_LAWS`, ledgers cite `24_...`, `02_METHOD`, etc.). The `03_`/`03_` duplicate is resolved by rename, not renumber.
7. **Content-level equation fixes are OUT of scope:** A9's 37/63-vs-50/50, "20 categories", Eq-50 re-pointing, and the `02_METHOD` Stage-5 contradiction remain content items for the equations owner (C10 items 10–12, 17). This pass only fixes *names and structure*.

---

**Summary for the licensor:**
- **Top-level structure:** 7 front-door files at root (LICENSE, README, UFT, ZERO-AS-WAVEFUNCTION, STATIC-UNIFICATION-CLAIMS, NUMBERS-INDEX, + THE-UNDERSTANDING kept as the front door) · `docs/` (manifest + 01–24, 4 renamed) · `laws/` (2,270) · `sim/` (2,285) · `validation/` (2,270 + 13) · `expansion_log/` (15) · `integration_audit/` (30 reports) · `tools/` (new: generation + audit scripts).
- **Renames:** 6 content renames (4 root docs, 2 equations collisions) + 10 audit-script renames + 1 audit-JSON rename = **17 renames**; 61 scripts relocated to `tools/`, 14 docs relocated to `docs/`, 4 superseded audit scripts dropped.
- **Delete candidates (approve before executing):** `__pycache__/` (41), `sim/__pycache__/` (1,253), `graphify-out/` (8,288 — untrack + gitignore, not deleted), 4 superseded audit scripts. **Nothing else deleted.** The `192_recursive_self_improvement.json` rename is confirmed complete.
- **Key risk:** the script relocation breaks relative paths unless the executor patches 15 `BASE` derivations and re-runs a generator to prove the pipeline still works.

*P1 planning pass — no files edited, no files deleted. The static canon is the κ_φ → 0 limit; the ground state of growth is 1 ≥ φ⁻¹.*
