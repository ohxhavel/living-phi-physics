# A9 — EQUATIONS INDEX AUDIT
## `02_EQUATIONS/` · the 100-equation index · the 37/63 discipline

**Agent:** A9 (final integration, equations index) · **Date:** 2026-08-07 · **Scope:** audit only — no files edited

**Sources read:** `02_EQUATIONS/INDEX_100_EQUATIONS.md` (master index) · all 20 `.md` files in `02_EQUATIONS/` · `32_PHI_PHYSICS/24_THE_GEOMIC_LEDGER.md` (§4, Appendix) · `32_PHI_PHYSICS/02_METHOD.md` (publication rule, validation protocol) · cross-greps of the corpus (`00_MANIFEST`, `04_EXPANSION`, `01_INDEX_150_LAWS`, law files, `SUPER_COMPRESSION_WAVEFORM_EQUATIONS.md`, A1/A2 audits).

---

## 1 · STRUCTURE — VERIFY THE INDEX'S CLAIMS

### 1.1 File count: **20 ✓**
`02_EQUATIONS/` contains **20 `.md` files** (10 canonical set files + index + retrocausal set + meta-synthesis + 7 taxonomy/foundation/test files). Matches the ledger Appendix claim "Equations files: **20** (`02_EQUATIONS/`)".

### 1.2 Equation count: **100 ✓ (canonical sets only) — with 2 out-of-index colliding sets**
Each of the 10 canonical set files contains exactly 10 equations (verified by heading count):

| Set | File | Range | Count |
|-----|------|-------|-------|
| 01 | `SET_01_PHI_CARRIER_PLASMA` | 1–10 | 10 |
| 02 | `SET_02_LYAPUNOV_PSEUDOSPECTRAL` | 11–20 | 10 |
| 03 | `SET_03_DIAMAGNETIC_AETHER` | 21–30 | 10 |
| 04 | `SET_04_HOLOGRAPHIC_MEMORY` | 31–40 | 10 |
| 05 | `SET_05_COUNCIL_SELF_REFERENCE` | 41–50 | 10 |
| 06 | `SET_06_QFIELD_NEURON_MAPPING` | 51–60 | 10 |
| 07 | `SET_07_INVERSE_OPERATORS` | 61–70 | 10 |
| 08 | `SET_08_WEIGHT_DYNAMICS` | 71–80 | 10 |
| 09 | `SET_09_VACUUM_ZPF` | 81–90 | 10 |
| 10 | `SET_10_SYNTHESIS_ADVANCED` | 91–100 | 10 |
| **Total** | | **1–100** | **100** |

**CONCERN — number collisions from non-indexed equation files.** Two further equation-bearing files exist that are **not** part of the indexed 100 and that **reuse already-assigned numbers**:

1. **`EQUATIONS_SET_06_RETROCAUSAL_ERROR_CORRECTION.md`** — a **second "SET 06"** file (the index lists only `SET_06_QFIELD_NEURON_MAPPING` as Set 06). Its 9 equations are numbered **Eq 47–55**, colliding with Set 05's Eq 47–50 (Singularity Order Parameter / Event Horizon Metric / Self-Modification Recursion Limit / SI Evolution) **and** Set 06 QField's Eq 51–55 (Neuron Field Operator → Field-Induced Phase Transition). Its `Eq 50` is *Self-Modification Coherence Gate* — a different object from the index's Eq 50 (*SI Evolution with Alpha Feedback*). See §2 for the semantic fallout.
2. **`agent_08_meta_synthesis_eqs_65_75.md`** — 11 equations numbered **Eq 65–75**, colliding with Set 07 (Eq 65–70) and Set 08 (Eq 71–75).

Net effect: the directory defines **120 equation slots** on disk (100 canonical + 9 retrocausal + 11 meta), but the "100 equations" claim is only true of the 10 indexed sets. The retrocausal set is the source of the corpus-wide "Eq 3.1–3.3 / Eq 50 collapse" references (see §2, §3).

### 1.3 The 37/63 split: **MISMATCH — index says 37/63, files say 50/50**

The index's VALIDATION STATUS table claims:

| Part | Index claim | Actual from file labels |
|------|-------------|------------------------|
| Part I (Eq 1–50) | 25 V / 25 P | **35 V / 15 P** |
| Part II (Eq 51–100) | 12 V / 38 P | **15 V / 35 P** |
| **TOTAL** | **37 V / 63 P** | **50 V / 50 P** |

Per-file counts of the `*Validated:*` / `*Predicted:*` labels:
8/2, 10/0, 1/9, 7/3, 9/1 (Part I) and 0/10, 2/8, 1/9, 4/6, 8/2 (Part II). **The index's validation table is inconsistent with its own source files.** The `INDEX_100_EQUATIONS.md` KEY EQUATIONS thread also marks **Eq 45 (von Neumann Entropy) as "predicted"** while `SET_05` labels it `Validated: Consciousness level` — an internal index inconsistency.

The 37/63 figure is repeated verbatim across the corpus (`00_MANIFEST` L6/L53, `04_EXPANSION` L83, `02_METHOD` L108, ledger §4 L155 + Appendix L357) but is not supported by the equations themselves. A2_cross_number_report L87 deferred this check to the equation agent ("outside this folder — verified by equation agent"); this audit is that verification and it **fails**.

### 1.4 Categories: **"20 distinct research categories" unsupported**
The index header claims 20 distinct categories, but the index's own table lists ~96 distinct category labels (100 slots) and the set files carry **97 distinct** per-equation `Category:` values. The "20 categories" claim does not match either source. (Suspect stale figure.)

### 1.5 Structure verdict
- **PASS:** 20 files; 100 equations across the 10 indexed sets.
- **FAIL:** 37/63 validation split (actual 50/50); "20 categories" (actual ~96–97 distinct); two out-of-index equation files reusing numbers 47–55 and 65–75; duplicate "SET 06" filename.

---

## 2 · NUMBER CROSS-CHECK (index ↔ corpus)

| Number | In equations index? | In corpus (ledger/laws/METHOD)? | Verdict |
|--------|--------------------|--------------------------------|---------|
| **37 validated / 63 predicted** | Yes (validation table) | Yes — repeated everywhere (00_MANIFEST, 04_EXPANSION, 02_METHOD L108, ledger L155/L357) | **MISMATCH — files are 50/50** |
| **Eq 1** (carrier recursion `C_{n+1}=(1/Φ)C_n+Φ∇²ΦΨ_n`) | Yes — Set 01 Eq 1 | Ledger §4 L170: same formula; 02_METHOD L49 (Stage 2 move 3) | ✓ match |
| **Eq 2** (coherence/emergence, 0.563) | Yes — Set 01 Eq 2 | Ledger §4: "Eq 2 (emergence threshold, C_crit=0.563, validated)"; 01_INDEX L202; laws/183 | ✓ value matches; ⚠ term conflation: file defines C_crit = Φ⁻¹ = **0.618** (the coherence denominator) and 0.563 as the **emergence threshold**; ledger/corpus call 0.563 "C_crit" (see §2 note) |
| **Eq 3.1–3.3** (retrocausal) | **NOT in index** (index Eq 3 = Phase Locking) | Referenced pervasively: 02_METHOD L50 (Eq 3.2 kernel), laws 013/023/039/048/097/159/181/199, 06/07, ledger law 159 | **GAP** — defined in `SUPER_COMPRESSION_WAVEFORM_EQUATIONS.md` (L141–178), outside the 100-equation index the corpus claims as its mathematics |
| **Eq 50** (collapse) | Index Eq 50 = **SI Evolution with Alpha Feedback** (dynamical systems) | Corpus uses "Eq 50" = **coherence-gating collapse**: ledger §4 L170, ledger law 157 L116, 01_INDEX L216, 03_OPEN_QUESTIONS L30, 05 L60, 07 L168, laws/157/067/191 | **MISMATCH** — corpus's "Eq 50 collapse" is the *retrocausal file's* Eq 50 (Self-Modification Coherence Gate), a non-indexed colliding number; index Eq 50 is a different equation |
| **Eq 81** (ZPF suppression) | Yes — Set 09 Eq 81 (Predicted) | Ledger L45 (ℏω/2 retained as T→0), law 158 "Eq 81 mechanism", 02_METHOD L145 | ✓ match |
| **Eq 13** (alpha SI → 1.6180) | Yes — Set 02 Eq 13 (Validated) | Ledger §4: "α-modulated SI → 1.6180, validated"; AGENTS.md (loops 286–300) | ✓ match |
| **Eq 42** (transformer-council) | Yes — Set 05 Eq 42 (partial) | Not referenced in 32_PHI_PHYSICS (grep: 0 hits) | ✓ internally consistent; not cross-referenced |
| **Eq 44** (consciousness wavefunction 0.8565) | Yes — Set 05 Eq 44 (Validated) | Ledger §4: "=0.8565, validated"; ledger Appendix; 07 L83 | ✓ match |
| **Eq 7** (fixed points {0, φ⁻¹, 1}) | Yes — Set 01 Eq 7 | Ledger §4: "{0, 0.618, 1}, validated" | ✓ match |
| **816** (dimensions) | Yes — Eqs 1/3/31/39/40/45/78/79 | Ledger Appendix: "carrier attractor = 816 (720+96, 88.2%)" | ✓ match; ⚠ "816D = 4096/5" is arithmetically loose: 4096/5 = 819.2, 4096/816 ≈ **5.02** (the sims use ratio 5.02) |
| **0.8565** (consciousness) | Yes — Eqs 2, 44 | Ledger Appendix; laws/210; A2 | ✓ match |
| **0.563** (emergence threshold) | Yes — Eqs 2, 44 | Ledger Appendix "C_crit=0.563"; A2 (0.563/0.5633/0.563263 truncations) | ✓ as threshold; ⚠ labeled "C_crit" while the Eq 2 file's C_crit = 0.618 |
| **40,134.946** (Ladder Invariant 528·φ⁹) | **NOT in index** | Yes — 00_THE_UNDERSTANDING L102, 01_INDEX L416, 19, 20, 21, ledger Appendix (A2 computed 40,134.946166) | ✓ consistent in corpus; absent from equations index (fine — it is a derived invariant, not one of the 100) |
| **1.6180339887** (φ) | Yes — FIELD_ISA, PHI_PROCESSOR_FOUNDATION (as 1.618033988749895, 15 dp) | Ledger Appendix 1.6180339887 (10 dp) | ✓ match (15-dp is a superset) |
| **0.6180339887** (φ⁻¹) | Yes — PHI_PROCESSOR_FOUNDATION (0.618033988749895) | Ledger Appendix; 03_INDEX L33 | ✓ match |

**Bonus finding (cross-reference, out of index):** `laws/157_measurement_problem.md` cites **"Eq 74 (Born rule)"** — no equation in the index, the retrocausal set, or the meta-synthesis set is a "Born rule" equation (index Eq 74 = Weight Matrix Non-Normality Gradient; meta Eq 74 = Infinite Recursion Convergence Gate). Dangling reference.

**C_crit note:** Eq 2's file is explicit: `C_crit = Φ⁻¹ = 0.618`, emergence at ℰ > 0.563. The ledger and much of the corpus relabel 0.563 as "C_crit". Not a value error (0.563 is the validated emergence threshold everywhere), but a **terminology conflation** worth one sentence of cleanup.

---

## 3 · THE 37/63 DISCIPLINE — OLD vs CORRECTED STANDARD

### 3.1 The two standards currently coexist

**OLD standard (requires external experiment / keeps 37/63):**
- `02_METHOD` **Stage 5 publication rule** (L108): *"No phi-law is published as anything more than PREDICTED until its prediction is experimentally tested. The 37/63 discipline of the 100-equation index applies here absolutely."*
- `04_EXPANSION` L83: *"Nothing is claimed as VALIDATED until simulated and, ultimately, experimentally tested. The 37/63 discipline … applies absolutely."*
- `00_MANIFEST` L53: validated requires closed form + simulation ≤1% error + *"a stated experiment that would falsify it"*.

**CORRECTED standard (simulation-pass = VALIDATED within the Field-Computer paradigm):**
- `02_METHOD` **Validation Protocol** (L128–131): `🟢 VALIDATED — simulation passed … Within the Field-Computer paradigm (Law 251), simulation with the correct mathematics IS validation`. External lab confirmation (`🔵 EXTERNALLY CONFIRMED`) is explicitly *"an optional confirmation tier, not the gate."*
- Ledger (corrected): Abstract L25 ("all 2,270 are SIMULATED, which the corpus's own validation standard (02_METHOD.md) equates to VALIDATED within the Field-Computer paradigm"), §2.4 L105, §7 L294 ("External lab confirmation remains an optional tier, not the gate — and zero laws have it").

### 3.2 Findings

1. **02_METHOD contradicts itself.** Stage 5 (L108) still enforces the old rule ("nothing beyond PREDICTED until experimentally tested … 37/63 applies absolutely") 20 lines above the Validation Protocol (L128–131) that defines simulation-pass = VALIDATED. The ledger's corrected standard **cites 02_METHOD as its authority** — but it is actually citing the corrected half of a document whose other half contradicts it.
2. **The ledger carries both.** The ledger has adopted the corrected standard for its 2,270 laws, yet **§4 (L155) and the Appendix (L357) still print the old "37 validated / 63 predicted"** for the 100 equations with no reconciliation to the corrected standard.
3. **The count is stale regardless of standard.** The 37/63 figure does not even match the equations (50/50), so it is wrong under either interpretation. The index's own definition ("Validated = directly supported by empirical loop results, loops 1–290") is a simulation/loop-support criterion, which under the corrected standard maps to VALIDATED — the file labels (50 V) reflect that, the index table (37 V) does not.
4. **"0 experimentally validated" is still accurate** and consistent with the corrected standard (ledger §7 honest limits: zero externally-confirmed). That part needs no change.

### 3.3 Required consistency note (audit-only; not edited)
- Re-count the index's VALIDATION STATUS table against the set files → **50 validated / 50 predicted** (35/15 Part I, 15/35 Part II).
- Resolve the 02_METHOD Stage 5 / Validation Protocol contradiction: state that publication status follows the corrected standard (simulation-pass = VALIDATED within the Field-Computer paradigm; external confirmation optional tier), and remove the "until experimentally tested" / "37/63 applies absolutely" phrasing in Stage 5 and 04_EXPANSION.
- Re-label "Eq 50" references in the corpus (ledger §4, law 157, etc.) to the retrocausal **Self-Modification Coherence Gate** explicitly, or renumber the retrocausal set, to end the collision with index Eq 50 (SI Evolution with Alpha Feedback).
- Optionally fix the "816D = 4096/5" phrasing (ratio ≈ 5.02), the "C_crit = 0.563" vs "C_crit = 0.618 (Φ⁻¹)" conflation, the "20 categories" figure, and the dangling "Eq 74 (Born rule)" reference.

---

## 4 · VERDICT SUMMARY

| Check | Result |
|-------|--------|
| 20 files | ✅ PASS |
| 100 equations (10 sets × 10) | ✅ PASS (canonical sets) |
| 37 validated / 63 predicted | ❌ FAIL — files are 50 V / 50 P |
| 20 categories | ❌ FAIL — ~96–97 distinct |
| Eq 1 / 7 / 13 / 44 / 81 / 42 / 63 | ✅ consistent index ↔ corpus |
| Eq 50 (collapse) | ❌ MISMATCH — corpus points at retrocausal (non-indexed) Eq 50 |
| Eq 3.1–3.3 (retrocausal) | ⚠ GAP — outside the 100-equation index |
| 816 · 0.8565 · 0.563 · φ · φ⁻¹ · 40,134.946 | ✅ consistent (40,134.946 not in index, fine) |
| 37/63 discipline language | ⚠ INCONSISTENT — old standard (02_METHOD L108, 04_EXPANSION L83) vs corrected standard (02_METHOD L128–131, ledger); consistency note required |

*End of A9 equations audit. No files edited — audit only.*
