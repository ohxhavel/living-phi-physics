# A7 · HISTORY DOCUMENTS AUDIT — GEOMIC PHYSICS LEDGER REGISTER CHECK

**Auditor:** Agent A7 (FINAL INTEGRATION) · **Date:** 2026-08-07 · **Scope:** docs 22, 23, 24

**Mandate:** verify the three history documents read as a **geomic physics ledger** (physics register, sourced, verdict-coded) and **not** conspiracy documentation. Requirement: "no conspiracy theory statements in the folder at all. All statements are ledger statements backed with actual data, actual statements made, actual discoveries — when, where, why, actual money, from whom, why funded, how suppressed, how the cage was built."

**Method:** full read of all three docs + targeted ripgrep scan (via grep tool) of the three files for the flagged terms, with line-level context; source verification against the thread files (`graphify-out/THREAD_*.md` — the investigation's primary/secondary evidence base), the docs' own sources lines, and the ledger's EVIDENCE columns.

---

## STEP 1 · CONSPIRACY-LANGUAGE SCAN

All line numbers are `file:line`. "Laws" = the physics-register uses in `laws/` (out of scope; the three docs are the audit target).

### 1.1 "they" as an anonymous agent — **0 occurrences**

Every `they/their` in the three docs has an explicit antecedent. Named, not anonymous:

| File:line | Antecedent |
|---|---|
| 22:16 | "their own work" → the founders (Newton…Penrose), enumerated in the same sentence |
| 22:179 | "the people who kept it alive" → enumerated giants |
| 23:22 / 24:179 | "their own eugenics office" → Carnegie + Rockefeller + Harriman, named |
| 23:241 | "they did, in primary sources" → the Greeks (subject of the row) |
| 23:274 / 24:25 | "they can be reversed" / "their discoverers" → Carnegie unit/SAT/partage → the mechanism's makers; the physics law discoverers |

No occurrence of "they" referring to a shadowy unnamed agent.

### 1.2 "suppressed" / "suppression" — **22 matches** in the three docs

| File:line | Context | Verdict |
|---|---|---|
| 22:31 | "His theology/alchemy were suppressed… papers sold at Sotheby's (1936)… studied from the 1970s" **[VERIFIED]** | **FLAG** — facts documented (1936 Sotheby's sale, 1970s study) but *no named suppressing institution*; the documented mechanism is neglect/non-study, not active suppression. "Suppressed" is stronger than the record. Rephrase to "marginalized / unstudied until the 1970s." |
| 22:50 | "The suppression was political (Bohm, Oppenheimer 1954)… no document shows a deliberate policy… **[PV]**" | Named persons + explicit no-policy caveat. OK |
| 22:89 | "political suppression of dissenters… **not** a documented conspiracy. No policy ever articulated the category. **[PV]**" | Explicit denial + named facts. OK |
| 23:4 | "where the popular 'conspiracy' claim is itself a myth — …the Smithsonian Atlantis suppression" | Name-the-myth. OK |
| 23:20 | "There was no coordinated suppression — there was a structural machine." | Explicit denial. OK |
| 23:108 | "Theology suppressed; clockwork built over him" (Newton row) **[VERIFIED]** | Same kernel as 22:31. **FLAG** — see 22:31 fix. |
| 23:198 | heading "Documented suppressions (with evidence)" | Register framing. OK |
| 23:229, 230 | "The Vatican suppressed the Dead Sea Scrolls" [MYTH]; "The Smithsonian suppressed Atlantis" [MYTH] | Name-the-myth, debunked inline. OK |
| 23:257 | "the post-WWII machine's documented purpose was the Cold War, not the suppression of living knowledge" | Explicit limit. OK |
| 23:261 | "It suppressed Wegener (wrongly) and cold fusion (rightly)" | Named cases. OK |
| 23:262 | "The suppression of persons was political (McCarthy, Bohm, Oppenheimer) and institutional (de Vaux's delay, Sarton's canon) — not a single doctrinal campaign" | Named institutions + facts. OK |
| 24:27, 209, 248, 250, 335 | register/prose framing; all tied to named institutions and facts, all carry "[VERIFIED]" or "[INFERENCE] on [VERIFIED] parts" | OK |
| 24:236, 237 | "The Vatican suppressed the DSS" / "The Smithsonian suppressed Atlantis" [MYTH] | Name-the-myth, debunked. OK |
| 24:115, 170, 282 | "ZPF suppression," "φ-suppression" | **Physics register** (Eq 81 mechanism). Not suppression-of-persons. OK |

**Suppression verdict:** every human-suppression use is tied to a named institution + documented fact, or explicitly denies a coordinated campaign, or names a myth and debunks it. One flag: **22:31 / 23:108 (Newton)** — "suppressed" overstates the documented mechanism (neglect).

### 1.3 "hidden" / "taken away" / "stolen" — **7 matches**

| File:line | Context | Verdict |
|---|---|---|
| 24:35, 60, 85, 87 | "the line is hidden" / "hidden zero" / "hidden-zero pattern" | **Physics register** — "hidden zero" = the assumed-rest/ideal-limit in each classical law. Not rhetoric. OK |
| 23:221 | "The 'living universe hidden' as the pattern behind the erasures — **[INFERENCE]** from documented cases" | Explicitly labeled [INFERENCE]. OK |
| 23:260 | "The 'hidden geometry' was hidden by neglect and structure, not by a coordinated erasure" | Anti-rhetoric clarification. OK |
| 23:2, 23:272 | "…and what was taken"; "**That is what was taken — and what the ledger shows was never fully taken**" | **FLAG (soft)** — "taken" is grounded in the enumerated verified-treasury list (Euclid, seked, Plimpton 322, Timbuktu 350,000…), so it denotes documented erasure-from-credit, not physical theft. No "stolen"/"taken away" phrase appears. Recommend a parenthetical, e.g. "taken *from the record / from the credit*" to lock the register. |
| 23:58 | "Taken; resold by FCO" (Benin Bronzes) | Documented event (1897 punitive expedition). OK |

No "stolen" / "taken away" in any of the three docs.

### 1.4 "cage" — **2 matches**

| File:line | Context | Verdict |
|---|---|---|
| 24:83 | "Faraday cage (1836)" | Physics law (a documented object). OK |
| 24:337 | "Register note on metaphor… Plato's cave (c. 375 BCE), Weber's 'iron cage' (*stahlhartes Gehäuse*, 1905; English 1930), Kuhn's box (1962)… The corpus's claim is never that a physical cage exists; it is that a measurement frame was propagated, and that frames… are documented and therefore revisable." | **Exactly the documented-metaphor register the user required.** PASS |

"cage" appears in **zero** rhetorical uses.

### 1.5 "conspiracy" — **9 matches**, every one either naming a myth or explicitly denying

| File:line | Use |
|---|---|
| 22:89 | "…**not** a documented conspiracy. No policy ever articulated the category." |
| 23:4 | names "the devil's-number zero, Nazi 440, the Vatican scrolls plot, the Smithsonian Atlantis suppression" as myths the report debunks |
| 23:16 | "The static worldview was **never imposed by a single conspiracy**. It was propagated by a set of documented mechanisms…" |
| 23:243 | ""The establishment is a conspiracy against heterodoxy" **[FALSE]**" (myth named, debunked) |
| 24:27 | "with sources and verdict codes, **not as conspiracy**" |
| 24:176 | "**No entry asserts a coordinated conspiracy**; the two anchoring facts forbid it" |
| 24:232 | table header "Myth (conspiracy side)" — labels a column |
| 24:244 | ""The establishment is a conspiracy against heterodoxy" [FALSE]" (myth named, debunked) |

"conspiracy" is **never asserted**. PASS.

### 1.6 "the machine" / "the machinery" — **~22 uses** in the three docs, every one defined by documented parts

| Representative use | Parts defined |
|---|---|
| 22:49 "The funding machine: Manhattan Project (1942) → AEC/ONR (1946) → NSF (1950…) → DARPA/NASA (1958)" | Named agencies + years |
| 23:16 / 23:252 / 24:335 "a machine with documented parts" | "the credit hour, the test score, the grant cycle, the partage dig, the textbook, the translation, the gatekeeping journal, the Whig history" — enumerated |
| 23:26 / 23:268 "machinery of measurement — the credit hour, the test, the grant cycle, the dig, the textbook, the translation, the gatekeeping journal" | enumerated |
| 23:20 "there was a structural machine" | follows the two anchoring documented facts |
| 23:257 / 24:250 "post-WWII machine's documented purpose was the Cold War" | explicit limit |
| 24:27 / 24:192 "the government machine" | defined by NSF/DoD/DOE/CERN row |
| 22:80 / 24:265 "la machine du monde" | verbatim Faye-1884 / Laplace-attribution quote |
| 23:189 "The extraction machine begins to be dismantled" (UNESCO 1970) | documented event |

"The machine" is always **a machine with documented parts**. PASS.

### 1.7 "forced upon" / similar — **0 occurrences**

No "forced upon," "imposed on humanity," "they took," "stolen from us" rhetoric anywhere in the three docs. (23:16 even negates "imposed by a single conspiracy.")

### 1.8 Exclamation marks — **15 lines in the three docs**, all benign except one

- **Factorial notation "0! = 1"**: 22:20, 22:72, 22:173, 24:44, 24:335 — mathematics, not exclamation.
- **Verbatim primary quotes containing "!"**: 22:94 (Mach: "I don't believe that atoms exist!"), 22:102 (Schrödinger: "…damned quantum jumping…!"), 22:128 / 22:152 / 23:111 / 24:261 (Tesla 1892: "Is this energy static or kinetic!"), 24:265 (Faye 1884). All flagged as quotations of documented statements.
- **EDITORIAL (1)**: **23:39** "Mount Wilson Observatory → Hubble → expansion **(the dynamic universe!)** | **[VERIFIED]**" — an enthusiasm marker inside a ledger table cell. **FLAG — remove the "!"** to keep the money-table register flat.

### 1.9 Rhetorical questions — **5 "?" lines, all expository framing, none persuasive**

- 22:12, 23:10, 23:12 — the investigation's framing questions in headers ("how did physics become static…? what was the system…?"); stated as the question asked, answered by the document.
- 22:63 "What is Life?" — a book title.
- 22:71 "When did nothing become the foundation? Documented chain: …" — a framing subheading immediately answered by a dated, cited chain.

No rhetorical-question persuasion. PASS.

---

## STEP 2 · SOURCE-BACKED CHECK (17 load-bearing entries)

Verdict scale: **[SOURCE OK]** = citation attached inline, in the doc's sources line, or in a thread file. **[SOURCE OK, INCOMPLETE]** = attached but missing a required detail. **[PARTIAL]** = source attached only at category level ("[VERIFIED]" or "X records"); a named citation is recommended. **[NO SOURCE]** = nothing anywhere (none found).

| # | Load-bearing entry | Where cited | Verdict / fix |
|---|---|---|---|
| 1 | GEB "molding hand" 1913 quote | 24:186 "GEB Occasional Papers No. 1 (1913, archive.org) **[VERIFIED]**"; 24:365 sources line; THREAD_01:71 fully: *Occasional Papers No. 1, "The Country School of To-Morrow"* (1913), **p. 6** | **[SOURCE OK, INCOMPLETE]** — the identifier **`countryschooloft00gates`** appears **nowhere in the corpus** (verified by grep). Fix: append to both 24:186 and the 24:365 sources line: "archive.org identifier `countryschooloft00gates`, p. 6." (Page is in the thread, not in doc 24.) |
| 2 | Rockefeller → UChicago 1890 ($600K + $10M 1910); GEB $180M | 24:185 "foundation histories **[VERIFIED]**"; THREAD_01:42 ($600K, 1890), :45 ($10M, 1910; total >$35M), :61 (GEB $180M total) | **[SOURCE OK]** — optional fix: name "University of Chicago history / Rockefeller Archive" in the EVIDENCE cell. |
| 3 | Carnegie Institution 1902 $10M → Mount Wilson → Hubble 1929 | 24:187; THREAD_01:101 ($10M, 1902), :113 (Hubble 1929 expansion) | **[SOURCE OK]** — optional fix: name "Carnegie Science history; Hubble 1929." |
| 4 | Carnegie CFAT 1905 → credit hour / GRE / ETS | 24:189 "CFAT records"; THREAD_01:135 (CFAT: Carnegie unit, TIAA, GRE initiated 1936, ETS), THREAD_04:16/112 (GRE 1936 by CFAT + 4 Ivy deans; ETS 1947 = College Board + Carnegie + ACE) | **[SOURCE OK]** — precision note: 23:41 attributes "credit hour, TIAA, GRE, ETS" to CFAT alone. Defensible per threads, but fix for precision: "Carnegie unit / credit hour, TIAA, **GRE (initiated by CFAT 1936)**, **ETS (co-founded 1947 with College Board + ACE)**." |
| 5 | Ford Foundation 1936 + CIA channel under McCloy 1958–65 | 24:190 "foundation histories"; THREAD_01:150 (founded 1936), :153 (90% of Ford Motor by 1947), :156 (McCloy 1958–65, "three-person committee… [CIA] requests"; Magat 2012, Saunders 1999) | **[SOURCE OK]** — optional fix: name "Saunders (1999), *The Cultural Cold War*" in EVIDENCE. |
| 6 | CCF ~$1M/yr 1950–67 | 24:191 "CCF records / Ramparts 1967"; THREAD_03:15, 93–115, 214 ($800K–$1M/yr; Farfield/Hoblitzelle/Kaplan fronts; CIA *Studies in Intelligence* 1995; Ramparts/NYT 1967; Saunders) | **[SOURCE OK]** |
| 7 | Reich book burning 23 Aug 1956, ~6 tons, Gansevoort | 24:211 "court records **[VERIFIED]**"; THREAD_09:7 (date, tons, incinerator, 25th St; "one of the worst examples of censorship in U.S. history") | **[SOURCE OK, PARTIAL]** — the quoted phrase's author is unnamed. Fix: name the quoter (standard Reich scholarship, e.g., Sharaf 1983, *Fury on Earth*). |
| 8 | Velikovsky Macmillan boycott 1950 | 24:213 EVIDENCE = bare "[VERIFIED]"; THREAD_09:8 (Shapley; moved to Doubleday; AAAS 1974) | **[PARTIAL]** — the **weakest-cited** suppression entry: no named citation in any doc or thread. Fix: add a named source (e.g., the Ellenberger account of the affair; AAAS 1974 symposium record). |
| 9 | McCarthy purges (Condon, F. Oppenheimer, Weinberg, Peters, Bohm) | 24:215 "Wang (1999)"; 23:202 "Wang 1999"; THREAD_09:9 | **[SOURCE OK]** — Wang 1999 (*American Science in an Age of Anxiety*) named. |
| 10 | DSS delay ~80% unpublished until 1991 | 24:217 "scrolls publication record **[VERIFIED]**"; 23:93/203 | **[PARTIAL]** — category-level only. Fix: name the standard record (e.g., the 1991 Huntington Library microfilm release / Facsimile Edition; Fitzmyer). |
| 11 | Knorozov Mayan decipherment 1952 → post-1975 | 24:219 "epigraphy histories **[VERIFIED]**"; 23:131/204 | **[PARTIAL]** — category-level only. Fix: name Coe, *Breaking the Maya Code* (1992). |
| 12 | Budge Amarna smuggling | 24:221 "Budge's own account"; THREAD_02:171 (*By Nile and Tigris*: "by means of bribery"); :172 (BM inflated rates); :173 (Fagan verdict) | **[SOURCE OK]** — fix (minor): name "*By Nile and Tigris*" in doc 24/23. |
| 13 | Greeks credited Egypt (Herodotus II, Plato *Timaeus* 22b, Aristotle *Metaphysics* 981b) | 24:225 — all four primary citations named **inline** (incl. Diodorus I.69) | **[SOURCE OK — full pass]** |
| 14 | Zilsel 1942 harmony→law | 24:226 — "Zilsel 1942 (*Phil. Rev.* 51:245); Lehoux 2012" | **[SOURCE OK — full pass]** |
| 15 | Noether 1918 | 24:227 — "Einstein's 1935 tribute; never a full professor" | **[PARTIAL]** — the 1918 theorem is standard; but the "Einstein 1935 tribute" and "never a full professor" claims have **no named citation**. Fix: add (e.g., the Noether obituary record / standard biography). |
| 16 | The myths | | |
| 16a | Nazi-440 | 23:213, 24:234 "[APOCRYPHAL] — Italy legislated 432 in 1884" | **[PARTIAL]** — the "Italy 432 (1884)" fact has no named citation. Fix: name the source (Italian pitch-standard history). |
| 16b | Devil's number (Nothaft 2020) | 22:74, 22:156, 23:228, 24:235 — Nothaft 2020 (*Brit. J. Hist. Math.*) named | **[SOURCE OK]** |
| 16c | Vatican scrolls | 23:229, 24:236 "[MYTH] — delay real, plot not" | **[SOURCE OK]** — debunk tied to the documented DSS institutional-failure record (#10). |
| 16d | Smithsonian Atlantis | 23:230, 24:237 "[MYTH]" | **[SOURCE OK]** — tied to Thomas 1894 (named at 24:205). |
| 16e | Government-killed-Reich | 23:231, 24:238 "[MYTH] — natural death (myocardial insufficiency, 3 Nov 1957); no pending appeal" | **[PARTIAL]** — death records not named. Fix: cite coroner's record / standard Reich biography (Sharaf 1983). |
| 16f | Koch-2023 | 23:232, 24:239 "[MYTH] — IIT won 2/3 (Cogitate protocol, *Nature*, 30 Apr 2025)" | **[SOURCE OK]** — *Nature* 30 Apr 2025 named; fix (minor): add the full bibliographic data (authors / DOI). |
| 17 | Money figures: Templeton ~$150M/yr; NSF ~$0.5B/yr; CERN ~€1.2B/yr | 24:192 "foundation records", 24:193 "NSF/CERN budgets **[VERIFIED / PV]**"; 22:142 labeled **[PV]** "order-of-magnitude estimate from documented anchors" | **[SOURCE OK]** — correctly kept at order-of-magnitude [PV] in 22:142; the 23:73–74 cells say [VERIFIED] — **recommend** aligning to "[VERIFIED / PV]" there too, matching 24:193. |

**STEP 2 RESULT: 17 / 17 pass — every entry has a source attached somewhere (doc sources line, EVIDENCE column, or thread file). 0 NO SOURCE.** Fixes needed: 1 incomplete (#1, GEB identifier), 6 partials needing a named citation (#7, #8, #10, #11, #15, #16a, #16e), 1 precision (#4), 2 minor (#12, #16f), 1 alignment (#17).

---

## STEP 3 · VERDICT-CODE CONSISTENCY

### 3.1 Declared vs used vocabulary

| Doc | Declared codes | Additional codes actually used |
|---|---|---|
| 22 (line 4) | VERIFIED, PV, APOCRYPHAL, FABRICATION | MYTH, FALSE, UNVERIFIED, PARAPHRASE, NOT FOUND in OCR, and composite labels (VERIFIED verbatim/debunking, APOCRYPHAL as legend) |
| 23 (line 4) | VERIFIED, PV, APOCRYPHAL, FABRICATION, INFERENCE | MYTH, FALSE, REJECTED, UNVERIFIED, VERIFIED, corrected |
| 24 (line 17) | VERIFIED, PV, APOCRYPHAL, FABRICATION, MYTH, INFERENCE, PROPOSED, REJECTED | **FALSE, UNVERIFIED, PARAPHRASE**, "APOCRYPHAL as told" — used in §6 watchlist (24:261–267) and §5.5 (24:237–244) but **not in the declared legend** |

**FLAG:** doc 24's legend omits three codes its own tables use. Fix: add **[FALSE]** (contradicted), **[UNVERIFIED]** (no provenance), **[PARAPHRASE]** (compressed/summarized) to the 24:17 legend (and mirror across 22/23 legends for one shared vocabulary).

### 3.2 Same claim, different codes across docs

| Claim | Doc 22 | Doc 23 | Doc 24 | Action |
|---|---|---|---|---|
| "Devil's number" | 22:74 **[APOCRYPHAL, DEBUNKED]**; 22:156 **[MYTH]** (Nothaft 2020) | 23:228 **[MYTH]** | 24:235 **[MYTH]** | **FLAG** — 22 uses both APOCRYPHAL and MYTH for the same claim; MYTH is the better fit (named + debunked). Unify to **[MYTH]** or define MYTH as the debunked-apocryphal category. |
| Flower of Life "3000 BCE cosmic code" | — | 23:145 **[FABRICATION]** | 24:241 **[MYTH]** | **FLAG** — same substance, different code. Unify (suggest [MYTH]: painted graffiti, documented ancient but not carved-3000-BCE). |
| Suppressed free-energy tech | — | 23:234 **[MYTH]** | 24:240 **[MYTH]** | consistent |
| Government-killed-Reich | — | 23:231 **[MYTH]** | 24:238 **[MYTH]** | consistent |
| Vatican scrolls / Smithsonian Atlantis | — | 23:229–230 **[MYTH]** | 24:236–237 **[MYTH]** | consistent |
| Nazi-440 | — | 23:213 **[APOCRYPHAL]** | 24:234 **[APOCRYPHAL]** | consistent |

### 3.3 [VERIFIED] claims with no named source (STEP-3 flag list)

All are attached to a category-level source (thread file or EVIDENCE label) — none is bare — but these five deserve a named citation to fully meet the ledger register:

1. **Velikovsky boycott** — EVIDENCE is bare "[VERIFIED]" (24:213); no named source anywhere.
2. **DSS ~80%** — "scrolls publication record" (24:217).
3. **Knorozov** — "epigraphy histories" (24:219).
4. **Noether** — "Einstein's 1935 tribute; never a full professor" (24:227), no citation.
5. **Newton "suppressed" theology** (22:31, 23:108) — see 1.2: factually anchored (Sotheby's 1936, 1970s study) but the verb overstates; either rephrase or add the specific history.

### 3.4 [MYTH] / [FABRICATION] claims actually debunked in-corpus

Every [MYTH]/[FABRICATION] in the myth tables (23 Part VII, 24 §5.5) carries its **debunk inline in the verdict cell** (e.g., "delay real, plot not"; "natural death… 3 Nov 1957"; "Nothaft 2020"; "IIT won 2/3"). Every fabrication in the watchlists (22 Part III, 24 §6) carries its **documented replacement**. The two anchoring facts (24:178–179) are [VERIFIED] and sourced. **No [MYTH] is left standing without a debunk; no [VERIFIED] is left without at least a category-level source.**

---

## STEP 4 · THE FIX LIST (exact)

**Language-register fixes (3 required, 1 optional):**
1. **23:39** — remove the editorial "!" from "(the dynamic universe!)" → "(the dynamic universe)". 
2. **22:31 and 23:108** — rephrase Newton "theology/alchemy were suppressed" → "theology/alchemy were **marginalized / left unstudied** (papers sold at Sotheby's 1936; public scholarship from the 1970s)" — the record documents neglect, not a suppressing institution.
3. **23:2 / 23:272** — "what was taken" / "That is what was taken" → add the register qualifier "taken **from the credit/record**" so it reads as documented erasure-from-credit, not theft. (No "stolen"/"taken away" appears; this is belt-and-braces.)
4. *(optional)* 23:16, 23:252 — the "machine with documented parts" phrase is already ideal; no change.

**Source fixes (8):**
5. **#1 GEB quote** — append archive.org identifier `countryschooloft00gates`, p. 6 to 24:186 and the 24:365 sources line (identifier is currently absent corpus-wide).
6. **#8 Velikovsky** — add a named citation to 24:213 / 23:201 (currently bare "[VERIFIED]").
7. **#7 Reich** — name the quoter of "one of the worst examples of censorship in U.S. history" (Sharaf 1983) in 24:211.
8. **#10 DSS** — name the scrolls record (e.g., 1991 Huntington microfilm release / Facsimile Edition) in 24:217 / 23:203.
9. **#11 Knorozov** — name Coe, *Breaking the Maya Code* (1992) in 24:219 / 23:204.
10. **#15 Noether** — add citation for the Einstein 1935 tribute and the "never a full professor" claim (24:227).
11. **#16a Nazi-440 / #16e Reich-death** — name the "Italy 432 (1884)" source and the death-record source (coroner / Sharaf 1983) in 24:234 / 24:238.
12. **#4 CFAT** — add the precision parenthetical "(GRE initiated by CFAT 1936; ETS co-founded 1947 with College Board + ACE)" at 23:41.
13. **#12 / #16f** — name *By Nile and Tigris* (24:221); complete the *Nature* 30 Apr 2025 bibliographic data (24:239).

**Vocabulary fixes (3):**
14. **24:17 legend** — add **[FALSE]**, **[UNVERIFIED]**, **[PARAPHRASE]** (used at 24:237–244, 24:261–267 but undeclared); mirror in 22:4 and 23:4 for a single shared vocabulary.
15. **Unify "devil's number"** to one code — [MYTH] — across 22:74, 22:156, 23:228, 24:235 (22 currently mixes APOCRYPHAL and MYTH).
16. **Unify "Flower of Life"** — 23:145 [FABRICATION] vs 24:241 [MYTH] → one code.

**Alignment fix (1):**
17. **Money-gap cells** (23:73–74) — align "[VERIFIED]" with 24:193's "[VERIFIED / PV]" (order-of-magnitude anchors), matching 22:142's [PV] label.

**Pointer fix (1):**
18. **23 sources line** — the thread-file pointer says "mds/technical_reports/STATIC_WORLDVIEW_THREAD_*.md, THREAD_*.md" but the files live at `graphify-out/THREAD_*.md` (only 6 of the claimed 15 exist: 01, 02, 03, 04, 08, 09; `STATIC_WORLDVIEW_THREAD_*.md` and `STATIC_WORLDVIEW_THREAD_15_THE_LEDGER.md` were not found). Fix the path; flag the missing threads/ledger for the pipeline.

---

## STEP 5 · SUMMARY

**Conspiracy-language scan:** ~55 flagged-term occurrences across the three docs (suppress 22 · hidden 7 · cage 2 · conspiracy 9 · machine ~22 · exclamation 15 · question 5 · "they" 0-anonymous · "forced upon" 0 · "stolen"/"taken away" 0). **All** occur in documented contexts: named institutions + documented facts, name-the-myth-with-debunk, physics register ("hidden zero," ZPF suppression, Faraday cage), verbatim primary quotes, or the explicit documented-metaphor note (Plato/Weber/Kuhn, 24:337). **Zero conspiracy-theory statements.** Exactly **2** editorial flags: 23:39 "!" and the Newton "suppressed" verb (22:31/23:108); "what was taken" (23:2/23:272) is a soft-register note, not rhetoric.

**Source-backed check:** **17/17 pass** — every load-bearing entry has a source attached (inline, sources line, or thread file). 0 NO SOURCE. 1 incomplete (GEB archive.org identifier missing), 6 partials needing a named citation (Reich quote, Velikovsky, DSS, Knorozov, Noether, Nazi-440/Reich-death), 1 precision (CFAT/GRE/ETS), 2 minor (Budge, Koch/Nature).

**Verdict-code consistency:** vocabulary is materially consistent; 3 flags — doc 24's legend omits FALSE/UNVERIFIED/PARAPHRASE that its own tables use; "devil's number" and "Flower of Life" each carry two different codes across docs; all [VERIFIED] claims have at least a category-level source, with 5 recommended named-citation upgrades. All [MYTH]/[FABRICATION] claims are debunked inline.

**Bottom line:** the three documents already read as a geomic physics ledger — verdict-coded, institution-named, money-figured, myth-named-and-debunked. The fixes above tighten the register (2 editorial, 1 soft) and lift the citation quality from category-level to named-primary (8 items), so the corpus can honestly claim every ledger statement is backed by a checkable source.

*No files were edited — audit only.*
