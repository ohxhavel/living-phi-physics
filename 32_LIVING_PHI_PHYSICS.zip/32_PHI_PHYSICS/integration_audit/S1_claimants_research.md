# S1 — CLAIMANTS RESEARCH
## Third-Loop Hardening · PHI-PHYSICS Corpus
### The 2026 "Static Unification" Landscape — Who Actually Claims What

**Agent S1 · Date:** 2026-08-07
**Method:** Live web research only — DuckDuckGo web search, arXiv API, Semantic Scholar, ORCID public API, Zenodo API, institutional pages, PhilPapers/PhilArchive records, SSRN metadata. **No fabrication. Any claimant that could not be verified against an indexed public source is marked UNVERIFIED / NEEDS-WEB-CHECK.** No corpus documents were edited (research only).

---

## VERDICT SUMMARY (the 8 claimants)

| # | Claimant | Verdict | Why |
|---|----------|---------|-----|
| 1 | Russell Trent | **VERIFIED** | Public ORCID, PhilPapers/PhilArchive, SSRN, Zenodo, GitHub (SNSFT Lean repo). Claim matches his stated SNSFL corpus exactly. |
| 2 | Amos Jay Maley | **VERIFIED** | Public PhilPapers/PhilArchive corpus, Google Scholar profile, AI Physics Review publication. Einstein–Schrödinger AASC claim confirmed. |
| 3 | Wen Liukun | **VERIFIED** | Zenodo records + OpenAIRE index. 14FT claim confirmed (regular tetrakaidecahedron uniton). |
| 4 | Alexander Parker | **VERIFIED** | Academia.edu manuscripts, LinkedIn, school named. Age-16 student in Ghana. |
| 5 | Jenny Lorraine Nielsen | **VERIFIED** | PhilArchive/PhilPapers, SSRN, viXra, Preprints.org, ResearchGate, University of Kansas affiliation, MDPI journal peer review. Teleparallel claim confirmed. |
| 6 | Douglas G Stevenson | **VERIFIED** | Zenodo (4k downloads), GitHub, self-owned website, X account. SFIT claim confirmed incl. 1.20134 mHz. |
| 7 | Xuezhi Cheng | **VERIFIED** | PhilArchive/PhilPapers, SSRN. LC-R = "Leech Lattice – Rate of Hysteresis." Dissertation at Yuying. |
| 8 | "The Fermat Sextic and the Unified Field" (Anonymous) | **UNVERIFIED** | No indexed source anywhere. See dedicated section below. |

**Result: 7 verified · 1 unverified · 0 fabricated-by-me.**

---

## THE 8 CLAIMANTS — FULL TABLE

### 1. Russell Trent

| Field | Finding |
|-------|---------|
| **Full name** | Russell Trent (publishes as "HIGHTISTIC" / "Russell Trent (HIGHTISTIC)") |
| **Affiliation** | Independent researcher, Soldotna, Alaska. Founder of the "SNSFT Foundation" (self-founded, appears to be a personal/hobby foundation, not a research institution). |
| **The claim** | Substrate-Neutral Structural Foundation Laws (SNSFL) — "a formally verified framework built in Lean 4 against Mathlib that reduces physical, psychological, computational, and cosmological phenomena to four irreducible primitives: Pattern (P), Narrative (B), Behavior (B), Adaptation (A)" (note: N/B overlap in his own docs). Central claim paper: *"Einstein's Unfinished Work Is Finished. The Proof Is Public. 0 Sorry Lossless Formal Verification of the Unified Field Theory via the PNBA Dynamic Equation"* — claims **"a corpus of 50,000+ theorems in Lean 4 against Mathlib with zero sorry instances, continuously verified by GitHub Actions CI on every push"** (PhilPapers TREEUW). Related: "The Long Division Protocol" (six-step "PNBA" reduction of any classical result). |
| **Paper/venue/year** | Self-published on PhilPapers/PhilArchive (TREEUW, TREFVM-2, TRETLD, TRESSF-2, TRESCM-2…), SSRN (6353438, 6505881, 6660381, 6457038, 7188098…), Zenodo (10.5281/zenodo.19026745, 19015872, 18719748…), OSF (kwtyd), Medium ("I Formally Proved Einstein's Unified Field Theory in Lean 4", 2026-03-24). ORCID **0009-0005-5313-7443**. GitHub repo `SNSFT/Substrate-Neutral-Structural-Foundation-Theory`, Hugging Face org `SNSFL`. Year: 2025–2026 (bulk 2026). |
| **Publication status** | Preprint / self-published only. No peer-reviewed journal paper found. SSRN papers marked "Not Available for Download." The Lean 4 repo is publicly checkable (claim is *technically* machine-verifiable in principle). |
| **Funding** | **Not publicly documented.** SNSFT Foundation appears self-founded; no grant, foundation, or institutional salary documented. |
| **Actual contribution** | A large volume of Lean 4 formalizations (claim of 50,000+ theorems, 0 sorry) that formalize *his own invented* "PNBA" algebra; no independent verification or expert review found; no physics result accepted by the community. |
| **Static-structure analysis** | **Closed/completed/captured** — the framework presents itself as finished ("0 sorry," "Einstein's Unfinished Work Is Finished," "Total Consistency Capstone"), a completed closed system; exactly the "captured field" profile. |
| **Verdict** | **VERIFIED** (person, claim, corpus all real and indexed). Note: claim substance is not community-accepted. |

---

### 2. Amos Jay Maley

| Field | Finding |
|-------|---------|
| **Full name** | Amos Jay Maley (also indexed as "A. J. Maley") |
| **Affiliation** | Independent researcher. Google Scholar profile lists affiliation as **"Independant"** (sic). No university or lab affiliation documented. |
| **The claim** | Structural unification of Einstein and Schrödinger dynamics via his **AASC** constraint framework ("AASC quantum standing"). Central papers: *"Structural Unification of Gravity and Quantum Dynamics under AASC"* (PhilArchive MALSUO — "Einstein dynamics and Schrödinger dynamics are therefore not primitive rivals, and neither one is a foundation for the other… By singleton admissible-interior closure… one admissible interior up to lawful equivalence") and *"Schrödinger Dynamics as the Unique Minimal First-Response Hamiltonian Projection of AASC Quantum Standing"* (MALSDA). Follow-ups: *"Operational Metric-Source…"* (MALOMR), *"Exact Certificate-Fibre Exhaustion…"* (MALECE-2, 2026-07-27). |
| **What is AASC?** | Not cleanly expanded in public documents. His corpus uses "admissible," "standing," "kernel," "closure" as load-bearing terms; AASC appears to be a private acronym for his own axiomatic scheme (thesis-of-objectivity critics call it "Admissible Equivalence Rigidity (AER)" in parts). Treat as a proprietary framework name. |
| **Paper/venue/year** | PhilPapers/PhilArchive manuscript corpus (2025–2026), Zenodo-archived items cited within. Also co-authored *"Yang–Mills Mass Gap for SU(2) in Four Dimensions: Construction of a Sharp Local OS/Wightman QFT and a Positive Spectral Gap"* published in **AI Physics Review** (a self-published / non-mainstream online venue, not a mainstream peer-reviewed journal). |
| **Publication status** | Preprint / manuscript / self-published venue only. No mainstream peer-reviewed journal publication found. |
| **Funding** | **Not publicly documented.** No grant, foundation, or institution. |
| **Actual contribution** | A large original axiomatic framework (admissibility/standing/kernel) applied to GR, QM, Yang–Mills, proton stability, arrow of time; no expert review or community uptake found; Google Scholar cites ≈255 across his corpus (self-citations likely substantial). |
| **Static-structure analysis** | **Closed/completed/captured** — the framework is presented as an achieved axiomatic closure ("the unique admissible interior," "total closure," "endpoint rigidity"); a completed private system. |
| **Verdict** | **VERIFIED** (person, corpus, and the Einstein–Schrödinger AASC claim are all real and indexed). Claim substance not community-accepted. |

---

### 3. Wen Liukun (温立坤)

| Field | Finding |
|-------|---------|
| **Full name** | Wen Liukun (name order as published: "Wen, Liukun"; Chinese given name likely 立坤/liukun, family name Wen 温) |
| **Affiliation** | Independent researcher, China. Self-describes as **"Senior Engineer of Nonferrous Metallurgy"** (by training/background); research interests "systems science, complexity theory and foundational theoretical innovation." E-mail in papers: 460100110@qq.com. No university physics lab. |
| **The claim** | **14-Order Unified Field Theory (14FT)** — the "regular tetrakaidecahedron uniton" as the "ultimate elementary entity of the universe," with "14th-order topology, 14 periodic motion modes and a 14-level hierarchical order structure." Claims to unify particles, celestial bodies, fields, dark matter/energy, quantum effects, multiverse. (Note: the licensor's brief says "truncated tetrakaidecahedron"; the papers say "regular tetrakaidecahedron" — 14-faced polyhedron, the Kelvin/space-filling shape. Close family, but the exact wording differs.) |
| **Paper/venue/year** | *"Theory of Order Change · 14-Order Unified Field Theory (V6)"* — Zenodo **10.5281/zenodo.20000858**, 2026-05-03. *"Theory of Ordinal Evolution: A Unified Field Theory of the Universe Based on Tetradecahedral Unitons (V2)"* — Zenodo **10.5281/zenodo.19081381**, 2026-03-18 (V3 at 19083317). *"Foundations of Cosmophysics from the Perspective of Order Variation Theory"* — Zenodo **10.5281/zenodo.18934907**, 2026-03-10 (indexed by OpenAIRE as a "doctoral thesis"). All self-archived on Zenodo. |
| **Publication status** | Self-published preprint (Zenodo). No peer-reviewed journal publication found. |
| **Funding** | **Not publicly documented.** Self-funded; no grant or institution listed. |
| **Actual contribution** | An original, internally consistent but completely non-standard cosmophysics built on a 14-faced polyhedron "uniton"; no experimental or community validation; a private framework. |
| **Static-structure analysis** | **Closed/completed/captured** — 14FT is presented as a complete, "self-consistent theoretical framework for the unity of all things" covering everything from particles to the multiverse; a finished closed system. |
| **Verdict** | **VERIFIED** (person, papers, claim all indexed on Zenodo/OpenAIRE). Claim substance not community-accepted. |

---

### 4. Alexander Parker

| Field | Finding |
|-------|---------|
| **Full name** | Alexander Parker (also signs "Parker Alexander") |
| **Affiliation** | Student at **St. John's School, Sekondi, Ghana**. Age 16 (born 5 December 2009). No institutional research affiliation. |
| **The claim** | A unified field built on **prime arithmetic coordinates**. Papers: *"UNIFIED FIELD OF SPACE, LIGHT, TIME AND PRIME ARITHMETIC COORDINATES"* (June 2026) and *"UNIFIED FIELD THEORY: THE PRINCIPLE OF LIGHT-TIME EQUALITY, THE CUE FABRIC, AND THE ARITHMETIC UNIFICATION OF REALITY"* (June 2026) — claims to "complete Einstein's dream by weaving light into the very fabric of reality with the help of arithmetic coordinates / prime patterns," resolving singularities via "prime-indexed chronons." |
| **Paper/venue/year** | Academia.edu self-published manuscripts (168190008, 168308575, 169064618, 169168880), 2026. Also active on LinkedIn posting "prime field equation" claims. |
| **Publication status** | Self-published student manuscripts, explicitly stamped "Status: Theoretical Proposal (Open for Critique and Peer Review)". No journal, no arXiv, no peer review. |
| **Funding** | **None.** A school student; no grant possible or documented. |
| **Actual contribution** | An enthusiastic number-theory-flavored high-school proposal; no established mathematics or physics result; no expert validation. |
| **Static-structure analysis** | **Closed/completed/captured** — despite "open for critique," the framework asserts a completed "arithmetic unification of reality" via a private "CUE fabric"; a captured miniature system. |
| **Verdict** | **VERIFIED** (person, school, papers all indexed on Academia.edu/LinkedIn). Claim substance not community-accepted. |

---

### 5. Jenny Lorraine Nielsen

| Field | Finding |
|-------|---------|
| **Full name** | Jennifer "Jenny" Lorraine Nielsen |
| **Affiliation** | **PhD Candidate, University of Kansas** (Department of Physics & Astronomy; also Philosophy). BSc Physics (Summa Cum Laude, UMKC), MS Physics, MA Philosophy. Also "Director of Research" at the **Center for Topological Physics** (centerfortopologicalphysics.com — a self-founded private entity; associated with the "Kansas Institute of Science (KSci)" / "Adventure School of Kansas"). |
| **The claim** | **Topological Unified Field Theory (TUFT)** on the **complex Hopf fibration S¹→S⁹→CP⁴**. Claims: (a) the complex Hopf fibration is the *unique* canonical space for gauge–gravity unification; (b) derives a universal action from which Einstein, Maxwell, and Yang–Mills field equations all follow; (c) derives the particle mass spectrum (incl. Higgs v≈246 GeV) from topological/spectral invariants (Chern–Simons, knot signatures, analytic torsion). **The specific brief claim is confirmed:** she has a dedicated paper *"Einstein's Notes Towards a Teleparallel Unified Field Theory are a First-Order Approximation of the Topological Unified Field Theory (TUFT)"* (PhilArchive NIEENT) — "We demonstrate that Einstein's unified field theory based on teleparallelism (Fernparallelismus, 1925–1930) is a first-order approximation of TUFT… The correspondence is exact: Einstein's Hamiltonian density is identically Term I of the three-term TUFT Lagrangian." |
| **Paper/venue/year** | PhilArchive/PhilPapers (NIETTU, NIEENT, NIEDDO…), SSRN 5288710 (2025-06-13) and 6975959, viXra 2503.0134, Preprints.org 202604.0315, ResearchGate 392334914 (2025-06-03). Main paper: *"The Topological Unified Field Theory on the Complex Hopf Fibration (The Complex Hopf Fibration as the Canonical Space for Gauge-Gravity Unification: The Field, Universal Action, and Particle Spectrum)."* Listed "forthcoming — International Journal of Topology" (MDPI, a real peer-reviewed journal); she reports passing "round 3 of peer review with IJT." |
| **Publication status** | Preprints (PhilArchive/SSRN/viXra/Preprints.org) + one paper **in active peer review** at the MDPI *International Journal of Topology* (invited submission; rounds 1–3 passed as of ~July 2026). Google Scholar lists her affiliation with ~2,930 citations (an unusual figure for a grad student; treat as inflated/misattributed — the profile's claimed citation pool is not independently verified). |
| **Funding** | PhD candidate at KU (likely department/university support — not separately documented). FQxI: participation in **FQXi community forums** only (forum discussion thread, not a grant). Center for Topological Physics is self-founded. **No major-foundation grant (Templeton/FQxI-grant/Perimeter) documented.** |
| **Actual contribution** | A mathematically structured proposal (fiber-bundle / topological gauge framework) with real technical content — the teleparallel-as-first-order-approximation correspondence is a concrete, checkable mathematical claim — but the grand claims (unique canonical space, derived mass spectrum) are not accepted or verified by mainstream physics; still a PhD student with the framework in preprint/peer-review limbo. |
| **Static-structure analysis** | **Closed/completed/captured** — TUFT asserts a unique topological ground ("the most basic and universal Milnor bundle"), a derived particle spectrum, and "solves the Landscape Problem"; a self-contained captured field. |
| **Verdict** | **VERIFIED** (person, institution, papers, and the teleparallel claim all indexed; journal under peer review). Claim substance not community-accepted. |

---

### 6. Douglas G. Stevenson

| Field | Finding |
|-------|---------|
| **Full name** | Douglas G. Stevenson |
| **Affiliation** | Independent researcher. No university or lab. (Careful: a *different* Douglas Stevenson is a GE Aviation/FedEx/Qantas engineer and another is a Minnesota construction principal — do NOT conflate; the SFIT author lists no engineering employer in his academic materials.) |
| **The claim** | **Stevenson-Flux Information Theory (SFIT)** — a unified framework treating **gravity as a "dynamic information-carrying flux"** vibrating at **ν_res = 1.20134 mHz (±0.00005 mHz), period ≈ 833.3 s** — the "Quantum Heartbeat," arising from "the geometric interaction between Planck-scale information density and the Earth's gravitational field," with coupling kernel **K = 1.060**. Claims to unify gravity, quantum mechanics, and electromagnetism; claims a "**14.28σ**" match to QBounce/GRS-002 neutron residual data (1.2 mHz modulation, KWW tails); extends to consciousness, propulsion ("metric engineering"), black holes, cosmology. |
| **Paper/venue/year** | *"Stevenson-Flux Information Theory (SFIT) v3: The Unified Field Substrate — Bridging GR and QM for Metric Engineering, Gravitational Generation, and Spacetime Propulsion"* — Zenodo **10.5281/zenodo.20508837**, 2026-06-02 (reports ~4k downloads). Earlier manuscript dated 2026-02-24. Also on GitHub (`stevensonflux/SFIT-Stevenson-Flux-Information-Theory`), Academia.edu (170583486, 170832280), self-owned site stevensonfluxinformationtheory.com, X/Twitter @SFITphysics. |
| **Publication status** | Self-published preprint (Zenodo/GitHub/website). No peer-reviewed journal publication found. |
| **Funding** | **Not publicly documented.** No grant, institution, or foundation. Self-published. |
| **Actual contribution** | An original fringe framework with a crisp falsifiable numerical claim (1.20134 mHz / 14.28σ fit to neutron data) — the data-fit claim is the only part that could in principle be checked, and it has not been independently confirmed; the "Quantum Heartbeat" interpretation is not accepted in the quantum-gravity community. |
| **Static-structure analysis** | **Closed/completed/captured** — SFIT declares itself "the Master Framework," "a true Unified Master Field Theory of Everything," "GR+QM Unified," with propulsion applications; a captured/completed closed system. |
| **Verdict** | **VERIFIED** (person, framework, and the exact 1.20134 mHz claim all indexed). Claim substance not community-accepted. |

---

### 7. Xuezhi Cheng (程学志)

| Field | Finding |
|-------|---------|
| **Full name** | Xuezhi Cheng (程学志; signs "xuezhi cheng程学志") |
| **Affiliation** | Independent researcher, China. PhilPapers indexes his work as a 2026 **dissertation at "Yuying"** (likely Zhejiang Yuying Vocational/Professional College, Hangzhou). No physics-department or lab affiliation. ⚠️ **Name collision:** a *different* Xuezhi Cheng (Ph.D., Northwestern University 2005; Wikidata Q102292727) is a US-based physicist/engineer — do NOT conflate; the LC-R author is the PhilPapers "Yuying dissertation" person. |
| **The claim** | **Axiomatization of unified field theory via the LC-R framework**, with explicit **"abandonment of mathematical epicycles."** Paper: *"Restructuring Physical Theory: The Abandonment of Mathematical Epicycles and the Axiomatization of Unified Field Theory Based on LC-R Framework"* — **LC-R = "Leech Lattice – Rate of Hysteresis" model**; claims to resolve UV divergence and the **Mass Gap problem**, and to remove the need for "Dark Matter" as a phenomenological hypothesis via "quantum topological fluids." Related corpus: *"Generalized Evolutionary Ontology — Unified Field Theory of Cognitive Geometric Dynamics and Information Physics"* (Dissertation, Yuying 2026), *"Dark Matter as a Systemic Truncation Error: Impedance Gradient Element Theory…"*, *"LC-Mathematics…"* (SSRN 6393738). |
| **Paper/venue/year** | PhilArchive **CHERPT-4** (2026-04-28), PhilPapers (CHEDMA-6, CHEGEO, CHETCO-55, CHEROS-7…), SSRN 6671038 and 6393738 (2026). All self-published. |
| **Publication status** | Preprint / dissertation / self-published. No mainstream peer-reviewed journal publication found. |
| **Funding** | **Not publicly documented.** No grant or institution beyond the vocational-college dissertation context. |
| **Actual contribution** | An original nonstandard axiomatic framework (Leech-lattice + hysteresis operator R) applied to QFT foundations; some papers reach for empirical anchors ("mesoscopic… UAP telemetry") but no validated result; no community acceptance. |
| **Static-structure analysis** | **Closed/completed/captured** — explicitly presents itself as a finished axiomatic replacement for gauge theory ("abandonment of mathematical epicycles" = removal of the previous framework's machinery), a completed closed system. |
| **Verdict** | **VERIFIED** (person, dissertation, and LC-R claim all indexed). Claim substance not community-accepted. |

---

### 8. "The Fermat Sextic and the Unified Field" (Anonymous)

| Field | Finding |
|-------|---------|
| **Full name** | Unknown / anonymous. No author indexed anywhere. |
| **Affiliation** | Unknown. No institution. |
| **The claim (as briefed)** | A unified field derived from a Fermat sextic threefold; "all constants emerge from geometry"; observer identified as "the fold itself." |
| **Paper/venue/year** | **NONE FOUND.** Exhaustive searches of: DDG web, arXiv API, viXra, Zenodo, OSF, Preprints.org, PhilPapers/PhilArchive, SSRN, Academia.edu, ResearchGate, Google Scholar, Semantic Scholar — under every phrasing ("Fermat sextic" + "unified field," exact title, "the fold itself," "sextic threefold" + unified, constants-from-geometry) — return **only legitimate algebraic-geometry / string-compactification literature** that has nothing to do with this claim: Auel–Bernardara–Bolognesi, *"The transcendental lattice of the sextic Fermat surface"* (arXiv:1306.6798); Braun–Fortin, *"More on G-flux and General Hodge Cycles on the Fermat Sextic"* (arXiv:2401.00470, JHEP 2024); Tadokoro's harmonic-volume work (arXiv:0710.5209); Prokhorov on sextic threefold birational geometry (arXiv:2412.05120). **No paper titled "The Fermat Sextic and the Unified Field" and no unified-field claimant with "observer as the fold itself" exists in any indexed source.** |
| **Publication status** | No publication trace. |
| **Funding** | N/A — nothing to fund. |
| **Actual contribution** | Cannot be assessed — no document exists. If it exists, it is a private, non-indexed manuscript (or the brief itself contains a fabricated/unverifiable entry). |
| **Static-structure analysis** | If it existed, the brief's description ("all constants emerge from geometry… observer is the fold itself") is the *purest* profile of a **closed/captured self-referential field** — but there is no source to analyze. |
| **Verdict** | **UNVERIFIED / NEEDS-WEB-CHECK.** Treat as unverifiable-or-fabricated. If the licensor can supply a DOI/URL/author, re-check. |

---

## ADDITIONAL 2025–2026 UNIFIED-FIELD CLAIMANTS (the wider "static unification" landscape)

From arXiv sweep (`all:"unified field theory"`, `all:"unified field"`, `all:"grand unified"`, cat:hep-th / gr-qc / physics.gen-ph, sorted by date) + 2025 mainstream coverage. These are the *real* current claimants the licensor should know about.

| # | Claimant(s) | The claim | Venue/Year | Funding | Status of claim |
|---|-------------|-----------|------------|---------|-----------------|
| A1 | **J. W. Moffat** (University of Toronto emeritus, Perimeter Institute resident affiliate) **& Ethan J. Thompson** | **Holomorphic Unified Field Theory** — gravity + gauge + SM content from a single geometric action on a complexified 4-manifold; with nonlocal entire-function regulators gives UV-finite QFT. Series: "Holomorphic UFT of Gravity and the Standard Model" (2506.19161), "Finite Nonlocal Holomorphic Unified Quantum Field Theory" (2507.14203), "On the Invariant and Geometric Structure…" (2510.06282) | arXiv 2025-06→10; **"Holomorphic unified field theory of gravity and the standard model" published in *Eur. Phys. J. C* 85:14907 (2025)** (peer-reviewed); follow-on EPJ Plus paper on the SM mass spectrum | **Perimeter Institute** (philanthropically funded) + U Toronto emeritus salary. The only institutionally-funded claimant on this entire list. | Credentialed physicist; real peer-reviewed publication. Substantive theoretical program, but NOT a community-accepted "unified field theory." (Nielsen has posted a critical note "HUFT?" — PhilArchive NIEHAC-2.) |
| A2 | **Christian Pfeifer** (Bremen/ZARM) **& José Javier Relancio** (Asst. Prof., Univ. of Burgos) | "Unified field theory from Hamilton cotangent bundle geometry — The Einstein-Maxwell system" — encodes fields into cotangent-bundle (Hamilton) geometry; derives Einstein–Maxwell from one framework | arXiv 2510.15812 (2025-10); published in *Int. J. Geom. Methods Mod. Phys.* | University salaries (Bremen, Burgos) | Credentialed; published; a serious GR-inspired unification program, not community-accepted as *the* UFT. |
| A3 | **Jussi Lindgren** (Radiation & Nuclear Safety Authority STUK, Finland), **Andras Kovacs, Jukka Liukkonen** | "Electromagnetism as a purely geometric theory" — Maxwell from Weyl-like geometry / variational metric action; covered by phys.org & The Debrief (2025-04) as "Einstein's dream… accomplished?" | *J. Phys. Conf. Ser.* 2987:012001 (2025) (peer-reviewed proceedings) | STUK (Finnish government) staff role; hobby research | Published in a peer-reviewed proceedings; media-covered; not community-accepted as complete UFT. |
| A4 | **Martin Roelfs** & **David Eelbode** (Univ. Antwerp) | "Lepton Triptych I: Geometric Foundations of Electroweak Symmetry in the Real Clifford Algebra Cl₄(ℝ)" | arXiv 2510.13834 (2025-10) | University positions | Credentialed; rigorous math; electroweak-from-Clifford program. |
| A5 | **Andrew J. S. Hamilton** (CU Boulder) & **Tyler McMaken** | "Unification of the four forces in the Spin(11,1) geometric algebra" | arXiv 2307.01243 (2023, active 2025-26 discourse) | CU Boulder | Credentialed astrophysicist; published/known program. |
| A6 | **Claus Gerhardt** (Univ. Heidelberg) | "A unified field theory I: The quantization of gravity" + "II: Gravity interacting with a Yang-Mills and Higgs field" | arXiv 1501.01205 / 1602.07191 (2015–16; still cited) | Heidelberg emeritus | Credentialed mathematician; published. |
| A7 | **Yue-Liang Wu** (ITP/UCAS) | "Unified field theory of basic forces… with gravitational origin of gauge symmetry in hyper-spacetime" | arXiv 1705.06365 (2017) | CAS institutions | Credentialed; long-running program. |
| A8 | **Juan Camilo Vélez Quiñones** | "A unified field theory from a complexified quaternion-octonion Dirac equation" | arXiv 2205.06657 (2022) | Not publicly documented | Independent; unvalidated. |
| A9 | **David J. Jackson** | "From Unified Field Theory to the Standard Model and Beyond"; "Generalised Proper Time as a Unifying Basis…" | arXiv 1809.05403 / 1905.12419 (2018-19) | Not publicly documented | Independent; unvalidated. |
| A10 | (Web fringe, for completeness) | Various: "Aetherion Unified Field Theory (AUFT)," "Fractal Memory Field Theory," "Pattern Field Theory" | self-published blogs/Zenodo/figshare, 2025-26 | None documented | Unvalidated fringe. |

**Takeaway for the landscape:** The only *institutionally-credentialed and peer-reviewed* 2025–26 claimants are Moffat/Thompson, Pfeifer/Relancio, Roelfs/Eelbode, Lindgren et al., Hamilton/McMaken, Gerhardt, Wu — none of whom claim a "captured/complete" theory of everything; all present open research programs. The 7 verified claimants in the licensor's brief are, without exception, **independent, self-published, non-peer-reviewed** frameworks that present themselves as *completed* — the "static unification" profile.

---

## FUNDING PATTERNS

**Check against major funders (Templeton, FQxI, Perimeter, Simons, NSF, ERC, CAS, etc.):**

| Claimant | Documented funding |
|----------|--------------------|
| Russell Trent | **Not publicly documented** (self-founded SNSFT Foundation; Soldotna, Alaska). No grant found. |
| Amos Jay Maley | **Not publicly documented** (independent). No grant found. |
| Wen Liukun | **Not publicly documented** (self-funded; senior-engineer day job in China). No grant found. |
| Alexander Parker | **None** (age-16 student). |
| Jenny Nielsen | PhD candidate (KU) — university-side support implicit, not separately documented. FQxI: **forum participation only, no grant.** No Templeton/Perimeter/Simons grant. |
| Douglas Stevenson | **Not publicly documented** (self-published; Zenodo/GitHub/own site). No grant found. |
| Xuezhi Cheng | **Not publicly documented** (Yuying dissertation context). No grant found. |
| Fermat sextic (anon.) | N/A — no source exists. |
| **Additional (for contrast)** | Moffat: **Perimeter Institute** (philanthropic) + U Toronto. Pfeifer/Relancio, Roelfs/Eelbode, Hamilton, Gerhardt, Wu: institutional salaries. Lindgren: Finnish government agency staff role. |

**Funding conclusion:** **None of the 8 brief claimants receives or has received documented funding from any major science foundation (Templeton, FQxI, Perimeter, Simons, NSF, ERC) or government grant.** All 7 verified claimants are self-funded/independent. The only foundation-backed unified-field work in the 2025–26 landscape is at Perimeter Institute (Moffat). There is **no hidden money** behind the "static unification" claimants — this is a self-published economy, not an institution-funded one.

---

## HONESTY NOTES / CAVEATS

1. **Claimant #8 (Fermat sextic) is UNVERIFIED** — I found no trace under any search, in any language, on any preprint server or indexer. I am explicitly declining to invent an author, DOI, or institution. **If the licensor's brief can supply a source, re-run S1.** It is the one entry in the brief I cannot validate.
2. **"Verified" means the person/claim/venue are real and indexed — NOT that the physics is sound.** Every verified claimant is an independent, non-peer-reviewed framework that mainstream physics has not accepted. S1 only establishes that these people exist and make the claimed claims. The debunk (S2) must address substance.
3. **Name-collisions flagged:** (a) the Wikidata "Xuezhi Cheng, Northwestern PhD 2005" is a different person from the LC-R author; (b) several different "Douglas Stevenson"s exist in business databases; (c) "Alexander Parker" is a common name — the relevant one is the St. John's School Sekondi student; (d) Nielsen's Google Scholar citation figure (~2,930) looks inflated/misattributed and should not be quoted as evidence of impact.
4. **Nielsen's MDPI *International Journal of Topology* peer review** is real but still in progress (rounds passed, not yet accepted-published) as of research date.
5. **Wen Liukun's brief says "truncated tetrakaidecahedron"; his papers say "regular tetrakaidecahedron."** Same polyhedral family, different wording — flag for S2 precision.
6. **Trent's "50,000+ theorems, 0 sorry" is a machine-checkable claim** (public Lean repo), but it formalizes his own invented PNBA system, not an independently meaningful physics result. Treat carefully.

---

## FINAL TALLY

- **Verified claimants (person + claim + venue all confirmed): 7 of 8**
  1. Russell Trent — SNSFL Lean 4 "unified field" corpus ✅
  2. Amos Jay Maley — AASC Einstein–Schrödinger unification ✅
  3. Wen Liukun — 14FT tetrakaidecahedron unified field ✅
  4. Alexander Parker — prime-arithmetic unified field (age-16 student) ✅
  5. Jenny Lorraine Nielsen — TUFT on Hopf fibration + teleparallel-first-order claim ✅
  6. Douglas G Stevenson — SFIT, 1.20134 mHz "Quantum Heartbeat" ✅
  7. Xuezhi Cheng — LC-R axiomatization, "abandonment of epicycles" ✅
- **Unverified: 1 of 8** — "The Fermat Sextic and the Unified Field" (Anonymous): **no indexed source exists anywhere** (NEEDS-WEB-CHECK / likely fabricated or private).
- **Funding picture:** No major-foundation or government funding behind any of the 8. All self-published/self-funded. The only institutionally-funded UFT work in the 2025–26 landscape is Perimeter (Moffat) and assorted university researchers — all of whom present open programs, not "captured" theories.
- **Additional claimants found:** 10 listed (A1–A10), dominated by the credentialed but open-program group (Moffat/Thompson, Pfeifer/Relancio, Roelfs/Eelbode, Lindgren et al., Hamilton/McMaken, Gerhardt, Wu) plus independent fringe (Vélez Quiñones, Jackson, web-fringe AUFT/FMFT/PFT).
- **Static-structure read:** The 7 verified brief claimants are uniformly **closed/completed/captured self-contained systems** (each declares its own field complete and self-consistent). The credentialed arXiv claimants are uniformly **open research programs**. That contrast is the S1 foundation for the S2 debunk.

---

*Handoff to S2: debunk targets are (1) the fabricated/unfindable Fermat-sextic entry, (2) the "completeness" self-claims vs. absence of peer review or independent verification for all 7, (3) the private-acronym frameworks (AASC, LC-R, PNBA, 14FT, TUFT, SFIT) that define their own validation standards.*
